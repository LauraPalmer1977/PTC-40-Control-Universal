'use strict';
// A fake vMix TCP API (port 8099) for testing tally without vMix.
//   node tools/mock-vmix.js            -> cuts Program/Preview between 4 inputs every 4 s
//   node tools/mock-vmix.js --static   -> Input 1 on Program, Input 2 on Preview, no changes

const net = require('net');
const PORT = 8099;
const STATIC = process.argv.includes('--static');
const inputs = [
  { key: 'a1b2c3d4-0001', title: 'PTZ 1 - Pulpit' },
  { key: 'a1b2c3d4-0002', title: 'PTZ 2 - Stage Wide' },
  { key: 'a1b2c3d4-0003', title: 'PTZ 3 - Choir' },
  { key: 'a1b2c3d4-0004', title: 'Slides & Lyrics' },
];
let program = 1, preview = 2;
const subscribers = new Set();
const tally = () => 'TALLY OK ' + inputs.map((_, i) => (i + 1 === program ? '1' : i + 1 === preview ? '2' : '0')).join('') + '\r\n';
const xml = () => '<vmix><version>27.0.0.49</version><inputs>' +
  inputs.map((x, i) => `<input key="${x.key}" number="${i + 1}" type="Capture" title="${x.title.replace(/&/g, '&amp;')}" state="Running">${x.title}</input>`).join('') +
  `</inputs><active>${program}</active><preview>${preview}</preview></vmix>`;

net.createServer((sock) => {
  console.log(`[vmix] client connected from ${sock.remoteAddress}`);
  let buf = '';
  sock.on('data', (d) => {
    buf += d.toString();
    let i;
    while ((i = buf.indexOf('\r\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 2);
      if (/^SUBSCRIBE TALLY/i.test(line)) { subscribers.add(sock); sock.write('SUBSCRIBE OK TALLY\r\n' + tally()); }
      else if (/^XML$/i.test(line)) { const x = Buffer.from(xml()); sock.write(`XML ${x.length}\r\n`); sock.write(x); }
      else if (/^TALLY$/i.test(line)) sock.write(tally());
    }
  });
  sock.on('error', () => {});
  sock.on('close', () => subscribers.delete(sock));
}).listen(PORT, () => console.log(`Mock vMix TCP API on ${PORT}${STATIC ? ' (static)' : ' (auto-cutting every 4 s)'}`));

if (!STATIC) {
  setInterval(() => {
    // "Cut": preview goes to program, next input goes to preview.
    program = preview;
    preview = (preview % inputs.length) + 1;
    console.log(`[vmix] CUT  program=${program} preview=${preview}`);
    for (const s of subscribers) s.write(tally());
  }, 4000);
}
