'use strict';
/* PTZ-Commander — browser UI. Talks only to the local server (server.js). */

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const clamp1 = (v) => Math.max(-1, Math.min(1, v));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } },
};

const S = {
  cameras: [], presets: {}, settings: {}, looks: [],
  vmix: { status: 'off', inputs: [] },
  activeId: store.get('activeCam', null),
  mode: 'recall',
  lastPreset: {},
  serverUp: false,
};
const active = () => S.cameras.find((c) => c.id === S.activeId) || null;

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------
async function api(method, path, body, { quiet = false } = {}) {
  try {
    const res = await fetch(path, {
      method, headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    if (data && data.ok === false && data.error && !quiet) toast(data.error, 'error');
    return data;
  } catch (e) {
    if (!quiet) toast(e.message, 'error');
    throw e;
  }
}
const camApi = (method, sub, body, opts) => {
  const c = active();
  if (!c) return Promise.reject(new Error('No camera selected'));
  return api(method, `/api/cam/${encodeURIComponent(c.id)}/${sub}`, body, opts);
};
const runCmd = (cmd, arg) => camApi('POST', 'cmd', { cmd, arg }).catch(() => {});

function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), kind === 'error' ? 4500 : 2200);
  while ($('#toasts').children.length > 3) $('#toasts').firstChild.remove();
}

// ---------------------------------------------------------------------------
// Live updates (Server-Sent Events)
// ---------------------------------------------------------------------------
function connectEvents() {
  const es = new EventSource('/api/events');
  es.addEventListener('snapshot', (e) => {
    const d = JSON.parse(e.data);
    S.cameras = d.cameras; S.presets = d.presets; S.settings = d.settings; S.looks = d.looks; S.vmix = d.vmix;
    S.video = d.video; S.protocols = d.protocols;
    if (!active() && S.cameras.length) selectCamera(S.cameras[0].id, { silent: true });
    S.serverUp = true; $('#connBanner').hidden = true;
    renderAll();
  });
  es.addEventListener('camStatus', (e) => {
    const d = JSON.parse(e.data);
    const c = S.cameras.find((x) => x.id === d.id); if (!c) return;
    c.status = d.status; c.error = d.error;
    renderTabs(); renderStatus();
  });
  es.addEventListener('camState', (e) => {
    const d = JSON.parse(e.data);
    const c = S.cameras.find((x) => x.id === d.id); if (!c) return;
    c.state = d.state; c.unsupported = d.unsupported || [];
    if (c.id === S.activeId) renderImage();
  });
  es.addEventListener('looks', (e) => { S.looks = JSON.parse(e.data); renderLooks(); });
  es.addEventListener('kelvin', (e) => {
    const d = JSON.parse(e.data);
    const c = S.cameras.find((x) => x.id === d.id);
    if (c && c.kelvinHttp) { c.kelvinHttp.last = d.kelvin; if (c.id === S.activeId) renderHttpKelvin(); }
  });
  es.addEventListener('vmix', (e) => { S.vmix = JSON.parse(e.data); renderVmix(); });
  es.addEventListener('video', (e) => { S.video = JSON.parse(e.data); videoUI.sync(); });
  es.addEventListener('tally', (e) => {
    const t = JSON.parse(e.data);
    let toPreview = null;
    for (const c of S.cameras) {
      const next = t[c.id] || 'off';
      if (next === 'preview' && c.tally !== 'preview') toPreview = c;
      c.tally = next;
    }
    if (toPreview && store.get('followPreview', false) && toPreview.id !== S.activeId && !motion.anyActive()) selectCamera(toPreview.id);
    else { renderTabs(); renderTally(); videoUI.render(); }
  });
  es.addEventListener('settings', (e) => { S.settings = JSON.parse(e.data); renderSpeeds(); renderPresets(); });
  es.addEventListener('presets', (e) => { S.presets = JSON.parse(e.data); renderPresets(); });
  es.addEventListener('preset', (e) => {
    const d = JSON.parse(e.data);
    if (d.action === 'recall') { S.lastPreset[d.id] = d.n; if (d.id === S.activeId) renderPresets(); }
  });
  es.addEventListener('traffic', (e) => logLine(JSON.parse(e.data)));
  es.onerror = () => { S.serverUp = false; $('#connBanner').hidden = false; };
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------
const ICON_EDIT = '<svg viewBox="0 0 24 24"><path d="M4 17.2V20h2.8l8.3-8.3-2.8-2.8L4 17.2zM19.7 7a1 1 0 0 0 0-1.4l-1.3-1.3a1 1 0 0 0-1.4 0l-1.1 1.1 2.8 2.8L19.7 7z"/></svg>';
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function renderAll() {
  renderTabs();
  const has = S.cameras.length > 0;
  $('#emptyState').hidden = has;
  $('#workspace').hidden = !has;
  if (!has) return;
  renderStatus(); renderSpeeds(); renderPresets(); renderImage(); renderHttpKelvin(); renderLooks(); renderTally(); renderVmix(); videoUI.sync();
}

function renderVmix() {
  const chip = $('#vmixChip'), v = S.vmix || {};
  chip.className = `vmix-chip ${v.status}`;
  chip.title = { off: 'vMix tally is off — click to set up', connecting: 'Connecting to vMix…', connected: `vMix connected · ${v.inputs.length} inputs`, disconnected: `vMix: ${v.error || 'not connected'}` }[v.status] || '';
}

function renderTally() {
  const c = active(), bar = $('#tallyBar');
  const t = c ? c.tally : 'off';
  bar.hidden = !c || t === 'off';
  bar.className = `tally-bar ${t}`;
  $('#workspace').classList.toggle('on-air', t === 'program');
  bar.textContent = t === 'program' ? `● ON AIR — ${c.name} is on vMix Program` : t === 'preview' ? `${c.name} is on vMix Preview` : '';
}

function renderTabs() {
  const nav = $('#camTabs');
  nav.innerHTML = S.cameras.map((c, i) => `
    <div class="cam-tab ${c.id === S.activeId ? 'active' : ''} tally-${esc(c.tally || 'off')}" style="--c:${esc(c.color || '#3b82f6')}" data-id="${esc(c.id)}" role="button" tabindex="0" title="${esc(c.ip)} — ${esc(c.status)}">
      <span class="num">${i + 1}</span><span>${esc(c.name)}</span>${c.tally === 'program' ? '<span class="tally-badge pgm">PGM</span>' : c.tally === 'preview' ? '<span class="tally-badge pvw">PVW</span>' : ''}<span class="dot ${esc(c.status)}"></span>
      <span class="edit" data-edit="${esc(c.id)}" title="Edit camera" role="button" aria-label="Edit ${esc(c.name)}">${ICON_EDIT}</span>
    </div>`).join('') + (S.cameras.length < 8 ? '<button class="cam-tab add" data-action="add-camera" title="Add camera">+ Add</button>' : '');
  const c = active();
  document.documentElement.style.setProperty('--cam', c ? c.color : 'var(--accent)');
}

function renderStatus() {
  const c = active(); if (!c) return;
  const el = $('#camStatus');
  const text = { connected: `Connected · ${c.ip}`, connecting: `Connecting to ${c.ip}…`, disconnected: `Offline · ${c.ip}`, disabled: 'Disabled' }[c.status] || c.status;
  el.className = `cam-status ${c.status}`;
  el.innerHTML = esc(text) + (c.status === 'disconnected' ? ' <button class="btn small ghost" data-action="reconnect">Retry</button>' : '');
  el.title = c.error || '';
  $('#workspace').classList.toggle('offline', c.status !== 'connected');
}

function renderSpeeds() {
  const s = S.settings;
  const set = (id, v) => { const pct = Math.round((v ?? 1) * 100); $(`#${id}`).value = pct; $(`#${id}v`).textContent = pct + '%'; };
  set('spdPT', s.panSpeed); set('spdZoom', s.zoomSpeed); set('spdFocus', s.focusSpeed);
}

function renderPresets() {
  const c = active(); if (!c) return;
  const count = S.settings.presetCount || 16;
  const names = S.presets[c.id] || {};
  const last = S.lastPreset[c.id];
  const grid = $('#presetGrid');
  grid.innerHTML = Array.from({ length: count }, (_, i) => {
    const n = i + 1, p = names[n] || {};
    const thumb = p.thumb ? `--thumb:url('/api/thumb/${encodeURIComponent(c.id)}/${n}?v=${p.thumb}');` : '';
    return `<button class="preset ${last === n ? 'last' : ''} ${p.thumb ? 'has-thumb' : ''}" data-n="${n}" style="${p.color ? `--pc:${esc(p.color)};` : ''}${thumb}">
      <span class="n">${n}</span><span class="name">${esc(p.name || '')}</span></button>`;
  }).join('');
  const panel = $('.panel.presets');
  panel.classList.toggle('store-mode', S.mode === 'store');
  panel.classList.toggle('edit-mode', S.mode === 'edit');
  $$('#presetMode button').forEach((b) => { const on = b.dataset.mode === S.mode; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); });
  const hint = $('#modeHint');
  hint.className = `mode-hint ${S.mode}`;
  hint.textContent = { recall: 'Click a preset to move the camera. Right-click to rename.', store: 'STORE: click a preset to save the current position to it.', edit: 'Click a preset to rename it.' }[S.mode];
}

// Image parameters with a direct value (ranges mirror lib/visca.js).
const signed = (v, c) => (v - c > 0 ? `+${v - c}` : String(v - c));
const PARAMS = {
  iris: { label: 'Iris', min: 0, max: 0x11, def: 0x0d },
  shutter: { label: 'Shutter', min: 0, max: 0x15, def: 0x07 },
  gain: { label: 'Gain', min: 0, max: 0x0f, def: 0 },
  bright: { label: 'Brightness', min: 0, max: 0x1f, def: 0x0f },
  expComp: { label: 'Exp. comp', min: 0, max: 0x0e, def: 7, fmt: (v) => signed(v, 7) },
  rGain: { label: 'Red', min: 0, max: 0xff, def: 0x80, fmt: (v) => signed(v, 0x80) },
  bGain: { label: 'Blue', min: 0, max: 0xff, def: 0x80, fmt: (v) => signed(v, 0x80) },
  colorGain: { label: 'Saturation', min: 0, max: 0x0e, def: 4, fmt: (v) => `${60 + v * 10}%` },
  hue: { label: 'Hue', min: 0, max: 0x0e, def: 7, fmt: (v) => `${signed(v * 2, 14)}°` }, // 0h = −14°, 7h = 0°, Eh = +14°
  colorTemp: { label: 'Kelvin', min: 0, max: 0x37, def: 31, fmt: (v) => `${2500 + v * 100} K` }, // 00h = 2500 K … 37h = 8000 K
  aperture: { label: 'Sharpness', min: 0, max: 0x0f, def: 5 },
  nr: { label: 'Noise red.', min: 0, max: 5, def: 2, fmt: (v) => (v === 0 ? 'Off' : String(v)) },
};
const dragging = new Set();
// Commands in Datavideo's control protocol Rev 2.7 (mirrors DATAVIDEO_DOCUMENTED in lib/visca.js).
const DATAVIDEO_DOCUMENTED = new Set(['power', 'focusMode', 'aeMode', 'wbMode', 'iris', 'shutter', 'gain', 'rGain', 'bGain', 'backlight', 'flip', 'colorTemp']);

function renderImage() {
  const c = active(); if (!c) return;
  const st = c.state || {};
  const na = new Set(c.unsupported || []);
  const showFor = (list, mode) => !mode || list.split(' ').includes(mode);
  // On Datavideo cameras, hide controls that aren't in Datavideo's protocol (unless extra controls are on).
  const extraHidden = (k) => !!c.limited && !DATAVIDEO_DOCUMENTED.has(k);
  $$('.seg[data-param]').forEach((el) => { el.hidden = extraHidden(el.dataset.param); });
  $$('[data-extra-param]').forEach((el) => { el.hidden = extraHidden(el.dataset.extraParam); });
  $$('[data-extra]').forEach((el) => { el.hidden = !!c.limited; });
  $('#limitedNote').hidden = !c.limited;
  $$('.seg[data-param] button').forEach((b) => {
    const k = b.parentElement.dataset.param;
    b.classList.toggle('on', String(st[k]) === b.dataset.arg);
    // A mode the camera rejected (e.g. VAR on a camera without colour-temperature control).
    const rejected = na.has(`${k}:${b.dataset.arg}`);
    b.disabled = rejected;
    b.title = rejected ? 'Not supported by this camera' : (b.dataset.title ?? b.title);
  });
  $$('[data-kelvin]').forEach((b) => { b.disabled = na.has('colorTemp'); });
  $$('.seg[data-param]').forEach((el) => el.classList.toggle('na', na.has(el.dataset.param)));
  $$('#focusMode button').forEach((b) => b.classList.toggle('on', b.dataset.val === st.focusMode));
  $$('.param[data-param]').forEach((el) => {
    const k = el.dataset.param, meta = PARAMS[k], v = st[k];
    el.hidden = extraHidden(k) || (el.dataset.ae && !showFor(el.dataset.ae, st.aeMode)) || (el.dataset.wb && !showFor(el.dataset.wb, st.wbMode));
    el.classList.toggle('na', na.has(k));
    el.title = na.has(k) ? 'Not supported by this camera' : '';
    const input = el.querySelector('input');
    input.disabled = na.has(k);
    if (v !== undefined && !dragging.has(k)) { input.value = v; }
    el.querySelector('output').textContent = v === undefined ? '—' : (meta.fmt ? meta.fmt(Number(input.value)) : input.value);
  });
  $$('[data-wb]:not(.param)').forEach((el) => { el.hidden = st.wbMode ? el.dataset.wb !== st.wbMode : false; });
  $$('input[type=checkbox][data-param]').forEach((i) => {
    const k = i.dataset.param;
    if (st[k] !== undefined) i.checked = !!st[k];
    i.closest('.switch').hidden = extraHidden(k);
    i.disabled = na.has(k);
    i.closest('.switch').classList.toggle('na', na.has(k));
    i.closest('.switch').title = na.has(k) ? 'Not supported by this camera' : '';
  });
  $$('[data-kelvin]').forEach((b) => b.classList.toggle('on', st.wbMode === 'var' && st.colorTemp === (b.dataset.kelvin - 2500) / 100));
  $('#aeHint').textContent = { auto: c.limited ? 'Camera sets iris, shutter and gain automatically.' : 'Camera sets iris, shutter and gain. Use Exp. comp to brighten or darken.', manual: 'You set iris, shutter and gain.', shutter: 'You set the shutter; the camera adjusts iris and gain.', iris: 'You set the iris; the camera adjusts shutter and gain.', bright: 'One brightness control drives iris and gain together.' }[st.aeMode] || '';
  $('#wbHint').textContent = { auto: 'Camera adjusts colour temperature continuously.', indoor: 'Fixed ≈3200 K (tungsten).', outdoor: 'Fixed ≈5600 K (daylight).', onepush: 'Fill the frame with white, then trigger.', atw: 'Auto tracking — wider range than Auto.', manual: 'Set red and blue gain yourself.', var: 'Set the colour temperature in Kelvin (2500–8000 K).' }[st.wbMode] || '';
  $('.focus-row').classList.toggle('disabled', st.focusMode === 'auto');
  $('#focusRocker').title = st.focusMode === 'auto' ? 'Switch to MF to focus manually' : '';
  $('#zoomPos').textContent = st.zoomPos === undefined ? '—' : `${Math.round((st.zoomPos / 0x4000) * 100)}%`;
  const p = $('#powerState');
  p.textContent = st.power === undefined ? '—' : st.power ? 'On' : 'Standby';
  p.className = `pill ${st.power ? 'on' : ''}`;
}

const LOOK_LABELS = { colorTemp: 'Colour temperature', aeMode: 'Exposure mode', wbMode: 'White balance', backlight: 'Backlight', expCompOn: 'Exp. comp on', wdr: 'WDR', defog: 'Defog', bw: 'B&W', gamma: 'Gamma' };

// Kelvin sent through the camera's web page (set up in the camera dialog).
function renderHttpKelvin() {
  const c = active(), box = $('#httpKelvin');
  const kh = c && c.kelvinHttp;
  box.hidden = !kh;
  if (!kh) return;
  if (!dragging.has('hk')) $('#hkRange').value = kh.last || 5600;
  $('#hkOut').textContent = `${$('#hkRange').value} K`;
  $$('[data-hk]').forEach((b) => b.classList.toggle('on', Number(b.dataset.hk) === kh.last));
}
async function sendHttpKelvin(k) {
  const c = active(); if (!c) return;
  try { await camApi('POST', 'kelvin', { kelvin: k }); } catch { /* toast shown */ }
  dragging.delete('hk');
  renderHttpKelvin();
}

function renderLooks() {
  const sel = $('#lookSelect'); if (!sel) return;
  const keep = sel.value;
  const builtin = S.looks.filter((l) => l.builtin), saved = S.looks.filter((l) => !l.builtin);
  sel.innerHTML = (saved.length ? `<optgroup label="Saved">${saved.map((l) => `<option value="${esc(l.id)}">${esc(l.name)}</option>`).join('')}</optgroup>` : '') +
    `<optgroup label="Built-in">${builtin.map((l) => `<option value="${esc(l.id)}">${esc(l.name)}</option>`).join('')}</optgroup>`;
  if (S.looks.some((l) => l.id === keep)) sel.value = keep;
  lookInfo();
}
function lookInfo() {
  const l = S.looks.find((x) => x.id === $('#lookSelect').value);
  $('#btnLookDelete').hidden = !l || l.builtin;
  $('#lookInfo').textContent = !l ? '' : l.builtin ? `Sets: ${Object.keys(l.values).map((k) => (PARAMS[k] ? PARAMS[k].label : LOOK_LABELS[k] || k)).join(', ')}` : `Saved from ${l.from} · ${new Date(l.created).toLocaleDateString()}`;
}

// ---------------------------------------------------------------------------
// Camera selection & CRUD
// ---------------------------------------------------------------------------
function selectCamera(id, { silent = false } = {}) {
  if (id === S.activeId && !silent) return;
  const prev = active();
  if (prev && motion.anyActive()) api('POST', `/api/cam/${prev.id}/stop`, null, { quiet: true }).catch(() => {});
  motion.reset();
  S.activeId = id; store.set('activeCam', id);
  renderAll();
}
function cycleCamera(dir) {
  if (!S.cameras.length) return;
  const i = S.cameras.findIndex((c) => c.id === S.activeId);
  selectCamera(S.cameras[(i + dir + S.cameras.length) % S.cameras.length].id);
}

function openCameraDialog(cam = null, prefill = {}) {
  const dlg = $('#dlgCamera'), f = $('#formCamera');
  f.reset();
  $('#dlgCameraTitle').textContent = cam ? 'Edit camera' : 'Add camera';
  const palette = ['#3b82f6', '#22c55e', '#f59e0b', '#a855f7', '#ec4899', '#14b8a6', '#ef4444', '#eab308'];
  const v = cam || { name: `Cam ${S.cameras.length + 1}`, ip: '', protocol: 'dvip', port: 5002, addr: 1, color: palette[S.cameras.length % palette.length], stream: '', ...prefill };
  $('#camProtocol').innerHTML = Object.entries(S.protocols || {}).map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`).join('');
  for (const k of ['name', 'ip', 'protocol', 'port', 'addr', 'color', 'stream']) f.elements[k].value = v[k] ?? '';
  const kh = cam && cam.kelvinHttp;
  f.elements.kelvinCurl.value = ''; f.elements.kelvinPass.value = ''; f.elements.kelvinRemove.checked = false;
  f.elements.kelvinUser.value = kh ? kh.user : '';
  f.elements.kelvinValue.value = 5600;
  $('#kelvinRemoveRow').hidden = !kh;
  $('#kelvinState').textContent = kh
    ? `Saved: ${kh.method} ${kh.url}${kh.body ? ` — body: ${kh.body}` : ''} (Kelvin goes where ${kh.token} is${kh.hasPass ? '; password saved' : ''}). Paste a new capture to replace it.`
    : 'Nothing saved yet.';
  $('#kelvinBox').open = false;
  if (!f.elements.protocol.value) f.elements.protocol.value = 'dvip';
  f.dataset.lastProto = f.elements.protocol.value;
  cameraHint();
  const sel = $('#camVmixInput'), cur = (cam && cam.vmixInput) || null;
  const inputs = (S.vmix && S.vmix.inputs) || [];
  let opts = '<option value="none">Not linked</option>' + inputs.map((i) => `<option value="${i.key ? esc(i.key) : i.number}">${i.number}. ${esc(i.title)}</option>`).join('');
  if (!inputs.length) opts += Array.from({ length: 20 }, (_, i) => `<option value="${i + 1}">Input ${i + 1}</option>`).join('');
  if (cur && !inputs.some((i) => i.key === cur.key || i.number === cur.number) && cur.number) opts += `<option value="${cur.number}">Input ${cur.number}${cur.title ? ` (${esc(cur.title)})` : ''}</option>`;
  sel.innerHTML = opts;
  const match = cur && (inputs.find((i) => cur.key && i.key === cur.key) || inputs.find((i) => i.number === cur.number));
  sel.value = !cur ? 'none' : match ? (match.key || String(match.number)) : String(cur.number);
  if (sel.value === '') sel.value = 'none';
  $('#btnDeleteCam').hidden = !cam;
  f.dataset.id = cam ? cam.id : '';
  dlg.showModal();
}

$('#formCamera').addEventListener('submit', async (e) => {
  const f = e.target;
  if (e.submitter && e.submitter.value === 'cancel') return;
  e.preventDefault();
  const body = Object.fromEntries(new FormData(f));
  try {
    const out = f.dataset.id ? await api('PUT', `/api/cameras/${f.dataset.id}`, body) : await api('POST', '/api/cameras', body);
    $('#dlgCamera').close();
    if (!f.dataset.id) selectCamera(out.id, { silent: true });
    toast(`Saved ${out.name}`, 'ok');
    renderDiscoverList();
  } catch { /* toast shown */ }
});
$('#btnDeleteCam').addEventListener('click', async () => {
  const id = $('#formCamera').dataset.id;
  const c = S.cameras.find((x) => x.id === id);
  if (!c || !confirm(`Remove "${c.name}" and its preset names from this controller?`)) return;
  await api('DELETE', `/api/cameras/${id}`).catch(() => {});
  $('#dlgCamera').close();
  if (S.activeId === id) S.activeId = null;
});

// ---------------------------------------------------------------------------
// Discovery & network
// ---------------------------------------------------------------------------
let discovered = [];
async function scan() {
  const list = $('#discoverList');
  list.innerHTML = '<div class="scanning"><span class="spinner"></span>Searching the network…</div>';
  try { discovered = await api('GET', '/api/discover'); } catch { discovered = []; }
  renderDiscoverList();
}
function renderDiscoverList() {
  const list = $('#discoverList');
  if (!$('#dlgDiscover').open) return;
  if (!discovered.length) {
    list.innerHTML = '<p class="hint">No DVIP devices answered. Check that the laptop and cameras are on the same network and subnet, and that your firewall allows UDP port 5002 — or add the camera by IP.</p>';
    return;
  }
  list.innerHTML = discovered.map((d, i) => {
    const added = S.cameras.some((c) => c.ip === d.ip);
    return `<div class="discover-item">
      <div class="title">${esc(d.model || 'DVIP device')} <span class="hint">${esc(d.hostname || '')}</span></div>
      <div class="actions">
        <button class="btn small ghost" data-net="${i}">Network…</button>
        <button class="btn small ${added ? '' : 'primary'}" data-add="${i}" ${added ? 'disabled' : ''}>${added ? 'Added' : 'Add'}</button>
      </div>
      <div class="meta">${esc(d.ip)} · ${esc(d.mac)} · ${d.dhcp ? 'DHCP' : 'Static'}${d.occupied ? ` · ${d.occupied} controller(s) connected` : ''}</div>
    </div>`;
  }).join('');
}
$('#discoverList').addEventListener('click', (e) => {
  const add = e.target.closest('[data-add]'), net = e.target.closest('[data-net]');
  if (add) { const d = discovered[add.dataset.add]; openCameraDialog(null, { ip: d.ip, name: `${d.model || 'Cam'} ${S.cameras.length + 1}`.trim() }); }
  if (net) openNetworkDialog(discovered[net.dataset.net]);
});
$('#btnRescan').addEventListener('click', scan);
function openDiscover() { $('#dlgDiscover').showModal(); scan(); }

function openNetworkDialog(d) {
  const f = $('#formNetwork');
  f.dataset.ip = d.ip;
  f.elements.dhcp.checked = d.dhcp;
  f.elements.newIp.value = d.ip; f.elements.netmask.value = d.netmask; f.elements.gateway.value = d.gateway;
  f.elements.hostname.value = d.hostname || '';
  f.elements.reboot.checked = true;
  $('#netInfo').textContent = `${d.model || 'Device'} · MAC ${d.mac} · currently ${d.ip}`;
  syncNetFields();
  $('#dlgNetwork').showModal();
}
function syncNetFields() { $('.static-fields').hidden = $('#formNetwork').elements.dhcp.checked; }
$('#formNetwork').elements.dhcp.addEventListener('change', syncNetFields);
$('#formNetwork').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target, el = f.elements;
  const body = { dhcp: el.dhcp.checked, hostname: el.hostname.value, reboot: el.reboot.checked };
  if (!el.dhcp.checked) Object.assign(body, { newIp: el.newIp.value, netmask: el.netmask.value, gateway: el.gateway.value });
  if (!confirm(`Apply new network settings to ${f.dataset.ip}?`)) return;
  try {
    await api('POST', `/api/network/${f.dataset.ip}`, body);
    toast('Network settings sent to the camera', 'ok');
    $('#dlgNetwork').close();
    setTimeout(scan, 4000);
  } catch { /* toast */ }
});

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
const PAD_DEFAULT = { pan: 0, tilt: 1, zoom: 3, focus: 'trig', invTilt: false, invZoom: false };
let padMap = { ...PAD_DEFAULT, ...store.get('padMap', {}) };

function openSettings() {
  const f = $('#formSettings'), s = S.settings, el = f.elements;
  el.presetCount.value = s.presetCount; el.presetBase.value = s.presetBase;
  el.invertPan.checked = !!s.invertPan; el.invertTilt.checked = !!s.invertTilt;
  el.vmixEnabled.checked = !!s.vmix.enabled; el.vmixHost.value = s.vmix.host; el.vmixPort.value = s.vmix.port;
  el.tallyLamp.value = s.tallyLamp; el.protectProgram.checked = !!s.protectProgram;
  el.extraControls.checked = !!s.extraControls;
  el.followPreview.checked = store.get('followPreview', false);
  el.tallyProgram.value = s.tallyHex.program; el.tallyPreview.value = s.tallyHex.preview; el.tallyOff.value = s.tallyHex.off;
  $('#vmixState').textContent = S.vmix.status === 'connected' ? `connected · ${S.vmix.inputs.length} inputs` : S.vmix.status === 'off' ? '' : (S.vmix.error || S.vmix.status);
  const pad = currentPad();
  const n = Math.max(pad ? pad.axes.length : 0, 6);
  const opts = (extra = '') => '<option value="none">None</option>' + extra + Array.from({ length: n }, (_, i) => `<option value="${i}">Axis ${i}</option>`).join('');
  el.padPan.innerHTML = opts(); el.padTilt.innerHTML = opts(); el.padZoom.innerHTML = opts();
  el.padFocus.innerHTML = opts('<option value="trig">LT / RT triggers</option>');
  el.padPan.value = padMap.pan; el.padTilt.value = padMap.tilt; el.padZoom.value = padMap.zoom; el.padFocus.value = padMap.focus;
  el.padInvTilt.checked = padMap.invTilt; el.padInvZoom.checked = padMap.invZoom;
  $('#dlgSettings').showModal();
}
$('#formSettings').addEventListener('submit', async (e) => {
  e.preventDefault();
  const el = e.target.elements;
  const axis = (v) => (v === 'none' || v === 'trig' ? v : Number(v));
  padMap = { pan: axis(el.padPan.value), tilt: axis(el.padTilt.value), zoom: axis(el.padZoom.value), focus: axis(el.padFocus.value), invTilt: el.padInvTilt.checked, invZoom: el.padInvZoom.checked };
  store.set('padMap', padMap);
  try {
    store.set('followPreview', el.followPreview.checked);
    await api('PUT', '/api/settings', {
      presetCount: el.presetCount.value, presetBase: el.presetBase.value, invertPan: el.invertPan.checked, invertTilt: el.invertTilt.checked,
      vmix: { enabled: el.vmixEnabled.checked, host: el.vmixHost.value, port: el.vmixPort.value },
      tallyLamp: el.tallyLamp.value, protectProgram: el.protectProgram.checked, extraControls: el.extraControls.checked,
      tallyHex: { program: el.tallyProgram.value, preview: el.tallyPreview.value, off: el.tallyOff.value },
    });
    $('#dlgSettings').close();
    toast('Settings saved', 'ok');
  } catch { /* toast */ }
});

// Speed sliders
for (const [id, key, also] of [['spdPT', 'panSpeed', 'tiltSpeed'], ['spdZoom', 'zoomSpeed'], ['spdFocus', 'focusSpeed']]) {
  const input = $(`#${id}`);
  input.addEventListener('input', () => { $(`#${id}v`).textContent = input.value + '%'; });
  input.addEventListener('change', () => {
    const v = input.value / 100;
    api('PUT', '/api/settings', also ? { [key]: v, [also]: v } : { [key]: v }).catch(() => {});
  });
}

// ---------------------------------------------------------------------------
// Presets
// ---------------------------------------------------------------------------
async function presetPress(n) {
  const c = active(); if (!c) return;
  const btn = $(`.preset[data-n="${n}"]`);
  if (S.mode === 'edit') return renamePreset(n);
  if (S.mode === 'store') {
    try {
      await camApi('POST', `preset/${n}/store`);
      btn && btn.classList.add('stored');
      const image = videoUI.capture(c.id);
      if (image) api('POST', `/api/cam/${encodeURIComponent(c.id)}/preset/${n}/thumb`, { image }, { quiet: true }).catch(() => {});
      toast(`Stored preset ${n} on ${c.name}`, 'ok');
    } catch { /* toast */ }
    setMode('recall'); // one store per arm, to avoid accidental overwrites
    return;
  }
  if (c.tally === 'program' && S.settings.protectProgram && !confirm(`${c.name} is ON AIR (vMix Program).\nRecall preset ${n} anyway?`)) return;
  S.lastPreset[c.id] = n;
  renderPresets();
  const b = $(`.preset[data-n="${n}"]`); b && b.classList.add('flash');
  camApi('POST', `preset/${n}/recall`).catch(() => {});
}

function renamePreset(n) {
  const c = active(); if (!c) return;
  const btn = $(`.preset[data-n="${n}"]`); if (!btn) return;
  const cur = (S.presets[c.id] || {})[n] || {};
  const nameEl = btn.querySelector('.name');
  const input = document.createElement('input');
  input.value = cur.name || ''; input.maxLength = 24; input.placeholder = 'Preset name';
  input.style.cssText = 'min-height:28px;padding:3px 6px;font-size:13px';
  nameEl.replaceWith(input);
  input.focus(); input.select();
  input.addEventListener('click', (e) => e.stopPropagation());
  let done = false;
  const finish = async (save) => {
    if (done) return; done = true;
    if (save && input.value !== (cur.name || '')) await camApi('PUT', `preset/${n}`, { name: input.value.trim() }).catch(() => {});
    renderPresets();
  };
  input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') finish(true); if (e.key === 'Escape') finish(false); });
  input.addEventListener('blur', () => finish(true));
}

function setMode(m) { S.mode = m; renderPresets(); }
$('#presetMode').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setMode(S.mode === b.dataset.mode && b.dataset.mode !== 'recall' ? 'recall' : b.dataset.mode); });
$('#presetGrid').addEventListener('click', (e) => { const b = e.target.closest('.preset'); if (b) presetPress(Number(b.dataset.n)); });
$('#presetGrid').addEventListener('contextmenu', (e) => { const b = e.target.closest('.preset'); if (b) { e.preventDefault(); renamePreset(Number(b.dataset.n)); } });

// ---------------------------------------------------------------------------
// Image controls
// ---------------------------------------------------------------------------
const setParam = (param, value) => camApi('POST', 'set', { param, value }).catch(() => {});

// Build slider rows: label · slider · value · reset
$$('.param[data-param]').forEach((el) => {
  const k = el.dataset.param, m = PARAMS[k];
  el.innerHTML = `<span>${m.label}</span><input type="range" min="${m.min}" max="${m.max}" step="1" aria-label="${m.label}"><output>—</output><button class="reset" title="Reset to default (${m.fmt ? m.fmt(m.def) : m.def})" aria-label="Reset ${m.label}">↺</button>`;
  const input = el.querySelector('input'), out = el.querySelector('output');
  let timer = null, lastSent = null;
  const push = () => { timer = null; const v = Number(input.value); if (v !== lastSent) { lastSent = v; setParam(k, v); } };
  input.addEventListener('input', () => {
    dragging.add(k);
    out.textContent = m.fmt ? m.fmt(Number(input.value)) : input.value;
    if (!timer) timer = setTimeout(push, 120); // live preview while dragging, throttled
  });
  input.addEventListener('change', () => { clearTimeout(timer); push(); setTimeout(() => dragging.delete(k), 400); lastSent = null; });
  el.querySelector('.reset').addEventListener('click', () => { input.value = m.def; out.textContent = m.fmt ? m.fmt(m.def) : m.def; setParam(k, m.def); });
});
$$('.seg[data-param]').forEach((seg) => seg.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  const k = seg.dataset.param;
  setParam(k, k === 'gamma' ? Number(b.dataset.arg) : b.dataset.arg);
}));
$$('input[type=checkbox][data-param]').forEach((i) => i.addEventListener('change', () => setParam(i.dataset.param, i.checked)));
$$('[data-kelvin]').forEach((b) => b.addEventListener('click', () => setParam('colorTemp', (Number(b.dataset.kelvin) - 2500) / 100)));
$('#hkRange').addEventListener('input', (e) => { dragging.add('hk'); $('#hkOut').textContent = `${e.target.value} K`; });
$('#hkRange').addEventListener('change', (e) => sendHttpKelvin(Number(e.target.value))); // one request when released
$('#hkReset').addEventListener('click', () => { $('#hkRange').value = 5600; sendHttpKelvin(5600); });
$$('[data-hk]').forEach((b) => b.addEventListener('click', () => { $('#hkRange').value = b.dataset.hk; sendHttpKelvin(Number(b.dataset.hk)); }));
$('#btnColorReset').addEventListener('click', () => { setParam('colorGain', PARAMS.colorGain.def); setParam('hue', PARAMS.hue.def); });

// Tabs inside the image panel
$('#imgTabs').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-tab]'); if (!b) return;
  $$('#imgTabs button').forEach((x) => { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b); });
  $$('.image .pane').forEach((p) => { p.hidden = p.dataset.pane !== b.dataset.tab; });
  store.set('imgTab', b.dataset.tab);
});
{ const t = store.get('imgTab', 'exposure'); const b = $(`#imgTabs button[data-tab="${t}"]`); b && b.click(); }

// Image presets
const lookName = () => (S.looks.find((x) => x.id === $('#lookSelect').value) || {}).name;
$('#lookSelect').addEventListener('change', lookInfo);
$('#btnLookApply').addEventListener('click', async () => {
  const id = $('#lookSelect').value; if (!id) return;
  try { const r = await camApi('POST', `look/${id}`); toast(`Applied "${lookName()}" to ${r.camera}`, 'ok'); } catch { /* toast */ }
});
$('#btnLookAll').addEventListener('click', async () => {
  const id = $('#lookSelect').value; if (!id) return;
  if (!confirm(`Apply "${lookName()}" to every connected camera?`)) return;
  try { const r = await api('POST', `/api/looks/${id}/apply-all`); toast(`Applied to ${r.length} camera(s)`, 'ok'); } catch { /* toast */ }
});
$('#btnMatchAll').addEventListener('click', async () => {
  const c = active(); if (!c) return;
  if (!confirm(`Copy ${c.name}'s exposure, white balance and colour settings to every other camera?`)) return;
  try { const r = await camApi('POST', 'match-all'); toast(r.length ? `Matched ${r.map((x) => x.camera).join(', ')} to ${c.name}` : 'No other camera is connected', r.length ? 'ok' : ''); } catch { /* toast */ }
});
$('#btnLookSave').addEventListener('click', async () => {
  const c = active(); if (!c) return;
  const name = prompt(`Name for the image preset (saved from ${c.name}'s current settings):`, '');
  if (!name || !name.trim()) return;
  try { const l = await api('POST', '/api/looks', { name, camera: c.id }); $('#lookSelect').value = l.id; renderLooks(); toast(`Saved "${l.name}"`, 'ok'); } catch { /* toast */ }
});
$('#btnLookDelete').addEventListener('click', async () => {
  const id = $('#lookSelect').value;
  if (!confirm(`Delete the image preset "${lookName()}"?`)) return;
  await api('DELETE', `/api/looks/${id}`).catch(() => {});
});
$('#vmixChip').addEventListener('click', openSettings);
$('#btnRefresh').addEventListener('click', () => camApi('POST', 'refresh').then(() => toast('Settings read from camera', 'ok')).catch(() => {}));

// Generic buttons with data-cmd (Home, AF/MF, Push AF, Power, WB trigger)
document.addEventListener('click', (e) => {
  const b = e.target.closest('button[data-cmd]');
  if (!b) return;
  if (b.dataset.confirm && !confirm(b.dataset.confirm)) return;
  const arg = b.dataset.arg === 'true' ? true : b.dataset.arg === 'false' ? false : b.dataset.arg;
  runCmd(b.dataset.cmd, arg);
});

// Generic actions
document.addEventListener('click', (e) => {
  const edit = e.target.closest('[data-edit]');
  if (edit) { e.stopPropagation(); return openCameraDialog(S.cameras.find((c) => c.id === edit.dataset.edit)); }
  const tab = e.target.closest('.cam-tab[data-id]');
  if (tab) return selectCamera(tab.dataset.id);
  const a = e.target.closest('[data-action]');
  if (a) {
    const act = a.dataset.action;
    if (act === 'add-camera') { $('#dlgDiscover').open && $('#dlgDiscover').close(); openCameraDialog(); }
    if (act === 'discover') openDiscover();
    if (act === 'reconnect') camApi('POST', 'reconnect').catch(() => {});
  }
  const close = e.target.closest('[data-close]');
  if (close) close.closest('dialog').close();
});
$('#camTabs').addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target.dataset.id) { e.preventDefault(); selectCamera(e.target.dataset.id); } });
$('#btnDiscover').addEventListener('click', openDiscover);
$('#btnSettings').addEventListener('click', openSettings);
$('#btnStop').addEventListener('click', () => { motion.reset(); camApi('POST', 'stop').catch(() => {}); });

// ---------------------------------------------------------------------------
// Motion engine: merges joystick, rockers, keyboard and gamepad into
// pan/tilt/zoom/focus values in -1..1 and streams them to the server.
// The server stops the camera if updates stop arriving (watchdog).
// ---------------------------------------------------------------------------
const motion = (() => {
  const src = { joy: [0, 0], keys: [0, 0], pad: [0, 0], zoomUi: 0, focusUi: 0, zoomKey: 0, focusKey: 0, zoomPad: 0, focusPad: 0 };
  const ch = {
    move: { last: null, at: 0, busy: false },
    zoom: { last: null, at: 0, busy: false },
    focus: { last: null, at: 0, busy: false },
  };
  let slow = false;
  const HEARTBEAT = 220;

  function send(name, value, body) {
    const c = ch[name], cam = active();
    if (!cam || c.busy || cam.status !== 'connected') return;
    const key = JSON.stringify(body);
    const zero = value === 0;
    const now = performance.now();
    if (key === c.last && (zero || now - c.at < HEARTBEAT)) return;
    c.busy = true; c.last = key; c.at = now;
    fetch(`/api/cam/${encodeURIComponent(cam.id)}/${name}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: key })
      .then((r) => r.json()).then((d) => { if (name === 'move' && d.pan !== undefined) $('#ptSpeed').textContent = `${Math.abs(d.pan)} / ${Math.abs(d.tilt)}`; })
      .catch(() => { c.last = null; })
      .finally(() => { c.busy = false; });
  }

  function tick() {
    const k = slow ? 0.35 : 1;
    const pan = clamp1(src.joy[0] + src.keys[0] + src.pad[0]) * k;
    const tilt = clamp1(src.joy[1] + src.keys[1] + src.pad[1]) * k;
    const zoom = clamp1(src.zoomUi + src.zoomKey + src.zoomPad);
    const focus = clamp1(src.focusUi + src.focusKey + src.focusPad);
    const r = (v) => Math.round(v * 100) / 100;
    send('move', pan || tilt ? 1 : 0, { pan: r(pan), tilt: r(tilt) });
    send('zoom', zoom, { v: r(zoom) });
    send('focus', focus, { v: r(focus) });
  }

  return {
    src, tick,
    get slow() { return slow; },
    set slow(v) { slow = v; toast(v ? 'Slow mode on' : 'Slow mode off'); },
    anyActive: () => Object.values(ch).some((c) => c.last && c.last !== '{"pan":0,"tilt":0}' && c.last !== '{"v":0}'),
    reset() {
      src.joy = [0, 0]; src.keys = [0, 0]; src.pad = [0, 0];
      src.zoomUi = src.focusUi = src.zoomKey = src.focusKey = src.zoomPad = src.focusPad = 0;
      for (const c of Object.values(ch)) c.last = null;
      keysDown.clear();
    },
  };
})();

// ----- Joystick -----
(function joystick() {
  const el = $('#joystick'), knob = $('#joyKnob');
  let id = null;
  const update = (e) => {
    const r = el.getBoundingClientRect();
    const radius = r.width / 2 - knob.offsetWidth / 2;
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (d > radius) { dx *= radius / d; dy *= radius / d; }
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    motion.src.joy = [dx / radius, -dy / radius];
  };
  const end = () => {
    if (id === null) return;
    id = null; el.classList.remove('active');
    knob.style.transform = ''; motion.src.joy = [0, 0];
  };
  el.addEventListener('pointerdown', (e) => { id = e.pointerId; el.setPointerCapture(id); el.classList.add('active'); update(e); });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === id) update(e); });
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end); el.addEventListener('lostpointercapture', end);
})();

// ----- Spring rockers (zoom vertical, focus horizontal) -----
function rocker(el, vertical, onValue) {
  const knob = el.querySelector('.rocker-knob');
  let id = null;
  const update = (e) => {
    const r = el.getBoundingClientRect();
    const half = (vertical ? r.height : r.width) / 2 - (vertical ? knob.offsetHeight : knob.offsetWidth) / 2;
    let d = vertical ? e.clientY - (r.top + r.height / 2) : e.clientX - (r.left + r.width / 2);
    d = Math.max(-half, Math.min(half, d));
    knob.style.transform = vertical ? `translate(-50%, calc(-50% + ${d}px))` : `translate(calc(-50% + ${d}px), -50%)`;
    onValue(vertical ? -d / half : d / half);
  };
  const end = () => { if (id === null) return; id = null; el.classList.remove('active'); knob.style.transform = ''; onValue(0); };
  el.addEventListener('pointerdown', (e) => { id = e.pointerId; el.setPointerCapture(id); el.classList.add('active'); update(e); });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === id) update(e); });
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end); el.addEventListener('lostpointercapture', end);
}
rocker($('#zoomRocker'), true, (v) => { motion.src.zoomUi = v; });
rocker($('#focusRocker'), false, (v) => { motion.src.focusUi = v; });

// ----- Keyboard -----
const keysDown = new Set();
const typing = (e) => e.target.closest('input, select, textarea, [contenteditable]') || document.querySelector('dialog[open]');
function keyAxes(shift) {
  const has = (...k) => k.some((x) => keysDown.has(x));
  const sp = shift ? 0.3 : 0.65;
  motion.src.keys = [
    ((has('ArrowRight', 'KeyD') ? 1 : 0) - (has('ArrowLeft', 'KeyA') ? 1 : 0)) * sp,
    ((has('ArrowUp', 'KeyW') ? 1 : 0) - (has('ArrowDown', 'KeyS') ? 1 : 0)) * sp,
  ];
  motion.src.zoomKey = ((has('KeyE') ? 1 : 0) - (has('KeyQ') ? 1 : 0)) * (shift ? 0.4 : 0.85);
  motion.src.focusKey = ((has('KeyX') ? 1 : 0) - (has('KeyZ') ? 1 : 0)) * (shift ? 0.3 : 0.7);
}
const AXIS_KEYS = new Set(['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyQ', 'KeyE', 'KeyZ', 'KeyX']);
document.addEventListener('keydown', (e) => {
  if (typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
  if (AXIS_KEYS.has(e.code)) { e.preventDefault(); keysDown.add(e.code); keyAxes(e.shiftKey); return; }
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') { keyAxes(true); return; }
  if (e.repeat) return;
  const digit = /^(Digit|Numpad)(\d)$/.exec(e.code);
  if (digit) {
    const d = Number(digit[2]);
    if (e.shiftKey && d >= 1 && d <= S.cameras.length) return selectCamera(S.cameras[d - 1].id);
    if (!e.shiftKey) return presetPress(d === 0 ? 10 : d);
  }
  if (e.code === 'BracketLeft') return cycleCamera(-1);
  if (e.code === 'BracketRight') return cycleCamera(1);
  if (e.code === 'KeyH') return runCmd('home');
  if (e.code === 'KeyF') return runCmd('focusOnePush');
  if (e.code === 'Space' || e.code === 'Escape') { e.preventDefault(); motion.reset(); camApi('POST', 'stop', null, { quiet: true }).catch(() => {}); }
});
document.addEventListener('keyup', (e) => {
  keysDown.delete(e.code);
  keyAxes(e.shiftKey);
});
window.addEventListener('blur', () => { keysDown.clear(); keyAxes(false); });

// ----- Gamepad -----
function currentPad() {
  const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
  return pads[0] || null;
}
const prevButtons = [];
function dz(v, d = 0.12) { return Math.abs(v) < d ? 0 : Math.sign(v) * (Math.abs(v) - d) / (1 - d); }
function pollPad() {
  const pad = currentPad();
  $('#padIndicator').hidden = !pad;
  if (!pad) { motion.src.pad = [0, 0]; motion.src.zoomPad = motion.src.focusPad = 0; return; }
  if (document.hidden) return;
  const ax = (i) => (i === 'none' || i === undefined || pad.axes[i] === undefined ? 0 : pad.axes[i]);
  motion.src.pad = [dz(ax(padMap.pan)), dz(-ax(padMap.tilt)) * (padMap.invTilt ? -1 : 1)];
  motion.src.zoomPad = dz(-ax(padMap.zoom)) * (padMap.invZoom ? -1 : 1);
  motion.src.focusPad = padMap.focus === 'trig'
    ? dz(((pad.buttons[7] && pad.buttons[7].value) || 0) - ((pad.buttons[6] && pad.buttons[6].value) || 0), 0.08)
    : dz(ax(padMap.focus));

  pad.buttons.forEach((b, i) => {
    const pressed = b.pressed, was = prevButtons[i];
    prevButtons[i] = pressed;
    if (!pressed || was || document.querySelector('dialog[open]')) return;
    const presetMap = { 0: 1, 1: 2, 2: 3, 3: 4, 12: 5, 15: 6, 13: 7, 14: 8 };
    if (i in presetMap) presetPress(presetMap[i]);
    else if (i === 4) cycleCamera(-1);
    else if (i === 5) cycleCamera(1);
    else if (i === 8) runCmd('focusOnePush');
    else if (i === 9) runCmd('home');
    else if (i === 10) motion.slow = !motion.slow;
  });

  if ($('#dlgSettings').open) {
    $('#padName').textContent = pad.id.slice(0, 48);
    $('#axisMeter').innerHTML = pad.axes.map((v, i) => `<div>Axis ${i}<i class="${v < 0 ? 'neg' : ''}" style="--v:${v.toFixed(2)}"></i></div>`).join('');
  }
}
window.addEventListener('gamepadconnected', (e) => toast(`Gamepad connected: ${e.gamepad.id.slice(0, 40)}`, 'ok'));
window.addEventListener('gamepaddisconnected', () => toast('Gamepad disconnected'));

// ---------------------------------------------------------------------------
// VISCA log
// ---------------------------------------------------------------------------
const logBuf = [];
function logLine({ id, dir, hex }) {
  const cam = S.cameras.find((c) => c.id === id);
  const t = new Date().toLocaleTimeString([], { hour12: false });
  const arrow = dir === 'tx' ? '→' : dir === 'rx' ? '←' : '!';
  logBuf.push(`<span class="${dir}">${t} ${esc(cam ? cam.name : id)} ${arrow} ${esc(hex)}</span>`);
  if (logBuf.length > 300) logBuf.splice(0, logBuf.length - 300);
  $('#logLast').textContent = `${cam ? cam.name : ''} ${arrow} ${hex}`;
  if ($('#log').classList.contains('open')) scheduleLogRender();
}
let logPending = false;
function scheduleLogRender() {
  if (logPending) return;
  logPending = true;
  requestAnimationFrame(() => {
    logPending = false;
    const pre = $('#logLines');
    const atBottom = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 8;
    pre.innerHTML = logBuf.join('\n');
    if (atBottom) pre.scrollTop = pre.scrollHeight;
  });
}
$('#logToggle').addEventListener('click', () => {
  const open = $('#log').classList.toggle('open');
  $('#logToggle').setAttribute('aria-expanded', open);
  if (open) scheduleLogRender();
});
$('#rawForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const hex = $('#rawHex').value;
  try {
    const r = await camApi('POST', 'raw', { hex });
    toast(r.reply ? `Reply: ${r.reply}` : r.ok ? 'Sent' : r.error, r.ok === false ? 'error' : 'ok');
  } catch { /* toast */ }
});

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
setInterval(() => { pollPad(); motion.tick(); }, 60);
document.addEventListener('visibilitychange', () => { if (document.hidden) motion.reset(); });
// Changing the protocol moves the port to that protocol's default (unless it was customised).
function cameraHint() {
  const f = $('#formCamera'), proto = f.elements.protocol.value;
  $('#camHint').textContent = {
    dvip: 'Datavideo cameras: DVIP on TCP port 5002. Leave the VISCA address at 1. Video: rtsp://CAMERA-IP:554/live/av1 (sub stream, set to H.264 under Video Encode).',
    'visca-tcp': 'PTZOptics / Avkans: enable VISCA over IP on the camera’s web page (default TCP 5678).',
    'visca-udp': 'PTZOptics / Avkans: VISCA over UDP (default port 1259). Use TCP if UDP gives no reply.',
    'sony-udp': 'Sony-style VISCA over IP (UDP 52381), also offered by many other brands.',
  }[proto] + (proto === 'dvip' ? '' : ' Video: copy the RTSP address from the camera’s web page (Streaming / RTSP). Prefer the H.264 sub-stream for previews.');
}
$('#camProtocol').addEventListener('change', (e) => {
  const f = $('#formCamera'), prev = f.dataset.lastProto, next = e.target.value;
  const prevDefault = S.protocols[prev] && String(S.protocols[prev].port);
  if (!f.elements.port.value || f.elements.port.value === prevDefault) f.elements.port.value = S.protocols[next].port;
  f.dataset.lastProto = next;
  cameraHint();
});

// ---------------------------------------------------------------------------
// Live video: one WebRTC connection per visible camera, relayed by the server to go2rtc.
// ---------------------------------------------------------------------------
const videoUI = (() => {
  const players = new Map(); // camId -> { url, pc, stream, state, error, retry }
  const tiles = new Map();   // camId -> tile element (kept so <video> elements don't flicker)
  let view = store.get('videoView', 'single');

  const wanted = () => {
    if (view === 'off' || !S.video || S.video.status !== 'running') return [];
    const list = view === 'grid' ? S.cameras : [active()].filter(Boolean);
    return list.filter((c) => c.stream);
  };

  function stop(id) {
    const p = players.get(id); if (!p) return;
    clearTimeout(p.retry);
    try { p.pc && p.pc.close(); } catch { /* closed */ }
    players.delete(id);
  }

  const iceDone = (pc, ms) => new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') return resolve();
    const t = setTimeout(resolve, ms);
    pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); resolve(); } });
  });

  async function start(cam) {
    const p = { url: cam.stream, state: 'connecting', error: null, stream: null };
    players.set(cam.id, p);
    render();
    const fail = (msg) => {
      if (players.get(cam.id) !== p) return;
      p.state = 'error'; p.error = msg;
      try { p.pc && p.pc.close(); } catch { /* closed */ }
      render();
      p.retry = setTimeout(() => { if (players.get(cam.id) === p) { players.delete(cam.id); sync(); } }, 5000);
    };
    try {
      const pc = new RTCPeerConnection({ iceServers: [] }); // local network only
      p.pc = pc;
      pc.addTransceiver('video', { direction: 'recvonly' });
      pc.ontrack = (e) => { p.stream = e.streams[0] || new MediaStream([e.track]); p.state = 'playing'; render(); };
      pc.onconnectionstatechange = () => { if (['failed', 'disconnected'].includes(pc.connectionState)) fail('Video connection lost — retrying…'); };
      await pc.setLocalDescription(await pc.createOffer());
      await iceDone(pc, 1500);
      const res = await fetch(`/api/video/webrtc/${encodeURIComponent(cam.id)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'offer', sdp: pc.localDescription.sdp }) });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || `HTTP ${res.status}`);
      if (players.get(cam.id) !== p) return pc.close();
      await pc.setRemoteDescription({ type: 'answer', sdp: d.sdp });
    } catch (e) { fail(e.message); }
  }

  function sync() {
    const want = wanted();
    const ids = new Set(want.map((c) => c.id));
    for (const id of [...players.keys()]) if (!ids.has(id)) stop(id);
    for (const c of want) {
      const p = players.get(c.id);
      if (p && p.url !== c.stream) stop(c.id);
      if (!players.has(c.id)) start(c);
    }
    render();
  }

  function tileFor(id) {
    let t = tiles.get(id);
    if (!t) {
      t = document.createElement('div');
      t.className = 'vtile'; t.dataset.id = id;
      t.innerHTML = '<video muted autoplay playsinline></video><div class="vlabel"></div><div class="vmsg"></div>';
      tiles.set(id, t);
    }
    return t;
  }

  function render() {
    const stage = $('#videoStage'); if (!stage) return;
    $$('#videoView button').forEach((b) => { const on = b.dataset.view === view; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); });
    $('#videoPanel').classList.toggle('collapsed', view === 'off');
    stage.className = `video-stage ${view}`;
    const v = S.video || {};
    if (view === 'off') { stage.replaceChildren(); return; }
    if (v.status === 'missing') {
      stage.innerHTML = '<div class="video-note"><b>Live video is not installed.</b> Close the controller, double-click <code>get-video-windows.bat</code> in the controller folder, then start it again. See the install guide, step 8.</div>';
      return;
    }
    const cams = view === 'grid' ? S.cameras : [active()].filter(Boolean);
    if (!cams.some((c) => c.stream)) {
      stage.innerHTML = `<div class="video-note">No video address yet. Click ✎ on a camera tab and paste its <b>RTSP</b> address (from the camera's web page) into <i>Video stream</i>.</div>`;
      return;
    }
    const els = cams.map((c, i) => {
      const t = tileFor(c.id), p = players.get(c.id), video = t.querySelector('video');
      t.className = `vtile tally-${c.tally || 'off'} ${c.id === S.activeId ? 'active' : ''}`;
      t.style.setProperty('--c', c.color || '#3b82f6');
      const n = S.cameras.indexOf(c) + 1;
      t.querySelector('.vlabel').innerHTML = `<span class="vnum">${n}</span>${esc(c.name)}${c.tally === 'program' ? ' <span class="tally-badge pgm">PGM</span>' : c.tally === 'preview' ? ' <span class="tally-badge pvw">PVW</span>' : ''}`;
      let msg = '';
      if (!c.stream) msg = 'No video address';
      else if (v.status !== 'running') msg = v.status === 'error' ? `Video engine error: ${v.error || ''}` : 'Starting video engine…';
      else if (!p || p.state === 'connecting') msg = '<span class="spinner"></span> Connecting video…';
      else if (p.state === 'error') msg = esc(p.error || 'Video error');
      t.querySelector('.vmsg').innerHTML = msg;
      t.querySelector('.vmsg').hidden = !msg;
      const stream = p && p.state === 'playing' ? p.stream : null;
      if (video.srcObject !== stream) { video.srcObject = stream; if (stream) video.play().catch(() => {}); }
      return t;
    });
    if (els.length !== stage.children.length || els.some((e, i) => stage.children[i] !== e)) stage.replaceChildren(...els);
  }

  // Grab a small JPEG of the camera's current picture (for preset thumbnails).
  function capture(id) {
    const t = tiles.get(id), video = t && t.querySelector('video');
    if (!video || !video.videoWidth || !t.isConnected) return null;
    const canvas = document.createElement('canvas');
    canvas.width = 240; canvas.height = Math.round(240 * video.videoHeight / video.videoWidth);
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    try { return canvas.toDataURL('image/jpeg', 0.7); } catch { return null; }
  }

  $('#videoView').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-view]'); if (!b) return;
    view = b.dataset.view; store.set('videoView', view); sync();
  });
  $('#videoStage').addEventListener('click', (e) => {
    const t = e.target.closest('.vtile'); if (t && view === 'grid') selectCamera(t.dataset.id);
  });
  document.addEventListener('visibilitychange', () => {
    // Free the network while the page is in the background; reconnect when it's back.
    if (document.hidden) [...players.keys()].forEach(stop); else sync();
  });

  return { sync, render, capture };
})();

connectEvents();
