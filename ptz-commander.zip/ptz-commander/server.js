'use strict';
// PTZ-Commander — local web server.
// Browsers can't open raw TCP/UDP sockets, so this server talks DVIP to the cameras
// and exposes a small HTTP + Server-Sent-Events API to the web UI (and later to vMix).

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { URL } = require('url');
const { Config } = require('./lib/config');
const { DvipCamera, PROTOCOLS, discover, network } = require('./lib/dvip');
const { Video } = require('./lib/video');
const { parseCurl } = require('./lib/curl');
const { httpRequest } = require('./lib/httpreq');
const { VmixClient } = require('./lib/vmix');
const { cmd, setBytes, DIRECT, TOGGLES, MODES, IMAGE_PARAMS, DATAVIDEO_DOCUMENTED, ZOOM_MAX, FOCUS_MAX, speedLimits } = require('./lib/visca');

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_FILE = process.env.CONFIG || path.join(__dirname, 'data', 'config.json');
const PUBLIC = path.join(__dirname, 'public');
const WATCHDOG_MS = 600; // a held move must be refreshed by the client at least this often

const config = new Config(DATA_FILE);
const cams = new Map(); // id -> { conn, motion }
const clients = new Set(); // SSE responses
const vmix = new VmixClient();
const tallyState = new Map(); // camera id -> 'program' | 'preview' | 'off'

// ---------------------------------------------------------------------------
// Camera lifecycle
// ---------------------------------------------------------------------------
// Datavideo cameras get only the commands in Datavideo's protocol, unless extra controls are on.
const isLimited = (camCfg) => (camCfg.protocol || 'dvip') === 'dvip' && !config.data.settings.extraControls;

function attach(camCfg) {
  const conn = new DvipCamera({ ...camCfg, limited: isLimited(camCfg) });
  conn.on('status', (status, err) => {
    broadcast('camStatus', { id: camCfg.id, status, error: err || null });
    if (status === 'connected') setTimeout(() => sendTallyLamp(camCfg, tallyState.get(camCfg.id) || 'off'), 300);
  });
  conn.on('state', (state) => broadcast('camState', { id: camCfg.id, state, unsupported: [...conn.unsupported] }));
  conn.on('traffic', (dir, hex) => broadcast('traffic', { id: camCfg.id, dir, hex }));
  conn.on('visca-error', (error) => broadcast('traffic', { id: camCfg.id, dir: 'err', hex: error }));
  cams.set(camCfg.id, { conn, motion: { pt: null, zoom: 0, focus: 0, timers: {} } });
  conn.connect();
}

function detach(id) {
  const c = cams.get(id);
  if (!c) return;
  Object.values(c.motion.timers).forEach(clearTimeout);
  c.conn.close();
  cams.delete(id);
}

config.data.cameras.forEach(attach);

// Live video (go2rtc). Started only when at least one camera has a stream URL.
const video = new Video(__dirname);
video.on('status', (v) => broadcast('video', v));
const syncVideo = () => video.setStreams(Object.fromEntries(config.data.cameras.map((c) => [c.id, c.stream || ''])));
const THUMBS = path.join(path.dirname(DATA_FILE), 'thumbs');

function camPublic(c) {
  const live = cams.get(c.id);
  return {
    ...c, status: live ? live.conn.status : 'disabled', error: live ? live.conn.lastError : null,
    state: live ? live.conn.state : {}, unsupported: live ? [...live.conn.unsupported] : [], tally: tallyState.get(c.id) || 'off',
    limited: isLimited(c),
    kelvinHttp: kelvinPublic(c.kelvinHttp),
  };
}

const vmixPublic = () => ({ status: vmix.status, error: vmix.error, inputs: vmix.inputs });

function snapshot() {
  return {
    cameras: config.data.cameras.map(camPublic), presets: config.data.presets, settings: config.data.settings,
    looks: [...BUILTIN_LOOKS, ...config.data.looks], vmix: vmixPublic(), video: video.public(),
    protocols: Object.fromEntries(Object.entries(PROTOCOLS).map(([k, v]) => [k, { label: v.label, port: v.port }])),
  };
}

// Cameras can be addressed by id ("cam-abc") or by 1-based position ("1") — the latter is handy for vMix.
function findCam(key) {
  let c = config.data.cameras.find((x) => x.id === key);
  if (!c && /^\d+$/.test(key)) c = config.data.cameras[Number(key) - 1];
  if (!c) throw httpError(404, `Unknown camera "${key}"`);
  return { cfg: c, ...cams.get(c.id) };
}

// ---------------------------------------------------------------------------
// Continuous motion with safety watchdog
// ---------------------------------------------------------------------------
const clamp1 = (v) => Math.max(-1, Math.min(1, Number(v) || 0));
const DEAD = 0.06;
const scaled = (v, max, mult) => {
  if (Math.abs(v) < DEAD) return 0;
  // Gentle curve: fine control near the centre, full speed at the edge.
  const mag = Math.pow((Math.abs(v) - DEAD) / (1 - DEAD), 1.6);
  return Math.sign(v) * Math.max(1, Math.round(mag * max * mult));
};

function armWatchdog(cam, axis, stopFn) {
  clearTimeout(cam.motion.timers[axis]);
  cam.motion.timers[axis] = setTimeout(stopFn, WATCHDOG_MS);
}

function movePanTilt(cam, pan, tilt) {
  const s = config.data.settings;
  const lim = speedLimits(cam.cfg.protocol);
  let p = scaled(clamp1(pan), lim.pan, s.panSpeed);
  let t = scaled(clamp1(tilt), lim.tilt, s.tiltSpeed);
  if (s.invertPan) p = -p;
  if (s.invertTilt) t = -t;
  const key = `${p},${t}`;
  const stop = () => { cam.motion.pt = '0,0'; cam.conn.send(cmd.panTiltStop(cam.cfg.addr), { key: 'pt' }).catch(() => {}); };
  if (p === 0 && t === 0) { clearTimeout(cam.motion.timers.pt); if (cam.motion.pt !== '0,0') stop(); return { pan: 0, tilt: 0 }; }
  armWatchdog(cam, 'pt', stop);
  if (cam.motion.pt !== key) {
    cam.motion.pt = key;
    cam.conn.send(cmd.panTilt(cam.cfg.addr, p, t, lim), { key: 'pt' }).catch(() => {});
  }
  return { pan: p, tilt: t };
}

function moveLens(cam, axis, v) {
  const s = config.data.settings;
  const isZoom = axis === 'zoom';
  const speed = scaled(clamp1(v), isZoom ? ZOOM_MAX : FOCUS_MAX, isZoom ? s.zoomSpeed : s.focusSpeed);
  const build = isZoom ? cmd.zoom : cmd.focus;
  const stop = () => { cam.motion[axis] = 0; cam.conn.send(build(cam.cfg.addr, 0), { key: axis }).catch(() => {}); };
  if (speed === 0) { clearTimeout(cam.motion.timers[axis]); stop(); return { speed: 0 }; }
  armWatchdog(cam, axis, stop);
  if (cam.motion[axis] !== speed) {
    cam.motion[axis] = speed;
    cam.conn.send(build(cam.cfg.addr, speed), { key: axis }).catch(() => {});
  }
  return { speed };
}

function stopAll(cam) {
  Object.values(cam.motion.timers).forEach(clearTimeout);
  cam.motion.pt = '0,0'; cam.motion.zoom = 0; cam.motion.focus = 0;
  return Promise.allSettled([
    cam.conn.send(cmd.panTiltStop(cam.cfg.addr), { key: 'pt' }),
    cam.conn.send(cmd.zoom(cam.cfg.addr, 0), { key: 'zoom' }),
    cam.conn.send(cmd.focus(cam.cfg.addr, 0), { key: 'focus' }),
  ]);
}

// Image / misc commands the UI is allowed to call by name: name -> argument validator.
const CMD_WHITELIST = {
  home: null, panTiltReset: null, power: 'bool', flip: 'bool', mirror: 'bool',
  focusAuto: null, focusManual: null, focusToggle: null, focusOnePush: null,
  aeMode: ['auto', 'manual', 'shutter', 'iris', 'bright'],
  iris: ['up', 'down', 'reset'], shutter: ['up', 'down', 'reset'], gain: ['up', 'down', 'reset'],
  bright: ['up', 'down', 'reset'], expComp: ['up', 'down', 'reset'], expCompOn: 'bool', backlight: 'bool',
  wbMode: ['auto', 'indoor', 'outdoor', 'onepush', 'atw', 'manual'], wbOnePushTrigger: null,
  rGain: ['up', 'down', 'reset'], bGain: ['up', 'down', 'reset'],
  aperture: ['up', 'down', 'reset'], noiseReduction: 'level',
};

async function runNamed(cam, name, arg) {
  if (!(name in CMD_WHITELIST)) throw httpError(400, `Unknown command "${name}"`);
  const rule = CMD_WHITELIST[name];
  if (Array.isArray(rule) && !rule.includes(arg)) throw httpError(400, `"${name}" expects one of: ${rule.join(', ')}`);
  if (rule === 'bool') arg = arg === true || arg === 'true' || arg === 'on' || arg === 1 || arg === '1';
  if (rule === 'level') { arg = Number(arg); if (!(arg >= 0 && arg <= 5)) throw httpError(400, 'level must be 0..5'); }
  const r = await cam.conn.send(cmd[name](cam.cfg.addr, arg));
  // Re-read state after changes that affect what the UI displays.
  setTimeout(() => cam.conn.connected && cam.conn.refreshState().catch(() => {}), 350);
  return r;
}

// Direct image parameter: { param, value } -> validated VISCA set command.
function validateParam(param, value) {
  if (DIRECT[param]) {
    const v = Number(value), p = DIRECT[param];
    if (!Number.isInteger(v) || v < p.min || v > p.max) throw httpError(400, `${param} must be ${p.min}..${p.max}`);
    return v;
  }
  if (TOGGLES[param] || param === 'defog' || param === 'bw') return value === true || value === 'true' || value === 'on' || value === 1 || value === '1';
  if (MODES[param]) {
    if (!(value in MODES[param].values)) throw httpError(400, `${param} must be one of: ${Object.keys(MODES[param].values).join(', ')}`);
    return value;
  }
  throw httpError(400, `Unknown parameter "${param}"`);
}

async function setParam(cam, param, value) {
  const v = validateParam(param, value);
  if (cam.conn.limited && !DATAVIDEO_DOCUMENTED.has(param)) {
    throw httpError(409, `${param} is not in Datavideo's control protocol. Turn on "Extra image controls" in Settings to try it.`);
  }
  const r = await cam.conn.send(setBytes(cam.cfg.addr, param, v));
  if (r && r.ok === false) {
    // "Syntax error" means the camera doesn't know this command: remember it so the UI greys it out.
    if (/syntax/i.test(r.error || '')) {
      const what = MODES[param] ? `${param}:${v}` : param;
      cam.conn.unsupported.add(what);
      if (what === 'wbMode:var') cam.conn.unsupported.add('colorTemp'); // no VAR mode, no Kelvin either
      cam.conn.noteState({});
      return { ok: false, error: `${cam.cfg.name} doesn't support ${what === 'wbMode:var' || param === 'colorTemp' ? 'VAR / Kelvin white balance' : param} (the camera answered "Syntax error").` };
    }
    return r;
  }
  cam.conn.noteState({ [param]: v });
  // Mode changes move the other values (e.g. iris jumps when leaving Auto): read them back.
  if (MODES[param] || param === 'expCompOn') {
    clearTimeout(cam.refreshTimer);
    cam.refreshTimer = setTimeout(() => cam.conn.connected && cam.conn.refreshState().catch(() => {}), 500);
  }
  return r;
}

// ---------------------------------------------------------------------------
// Image presets ("looks"): a set of image values that can be applied to any camera
// ---------------------------------------------------------------------------
const BUILTIN_LOOKS = [
  { id: 'b-auto', name: 'Full auto (reset look)', builtin: true, values: { aeMode: 'auto', wbMode: 'auto', backlight: false, expCompOn: false, wdr: false, defog: false, bw: false, colorGain: 4, hue: 7, gamma: 0 } },
  { id: 'b-daylight', name: 'Daylight / outdoor', builtin: true, values: { aeMode: 'auto', wbMode: 'outdoor' } },
  { id: 'b-tungsten', name: 'Tungsten stage / indoor', builtin: true, values: { aeMode: 'auto', wbMode: 'indoor' } },
  { id: 'b-3200k', name: 'VAR 3200 K (tungsten)', builtin: true, values: { wbMode: 'var', colorTemp: 7 } },
  { id: 'b-5600k', name: 'VAR 5600 K (daylight)', builtin: true, values: { wbMode: 'var', colorTemp: 31 } },
  { id: 'b-backlit', name: 'Backlit (window, bright stage)', builtin: true, values: { aeMode: 'auto', backlight: true, wdr: true } },
  { id: 'b-lowlight', name: 'Low light', builtin: true, values: { aeMode: 'auto', expCompOn: true, expComp: 0x0a, nr: 3 } },
  { id: 'b-vivid', name: 'Vivid colour', builtin: true, values: { colorGain: 6 } },
  { id: 'b-natural', name: 'Natural colour', builtin: true, values: { colorGain: 4, hue: 7 } },
  { id: 'b-bw', name: 'Black & white', builtin: true, values: { bw: true } },
];
const APPLY_ORDER = ['aeMode', 'wbMode', 'expCompOn', 'backlight', 'wdr', 'defog', 'bw', 'iris', 'shutter', 'gain', 'bright', 'expComp', 'rGain', 'bGain', 'colorTemp', 'colorGain', 'hue', 'gamma', 'aperture', 'nr'];
const RELEVANT = {
  iris: (ae) => ae === 'manual' || ae === 'iris',
  shutter: (ae) => ae === 'manual' || ae === 'shutter',
  gain: (ae) => ae === 'manual',
  bright: (ae) => ae === 'bright',
  expComp: (ae, wb, ec) => ec,
  rGain: (ae, wb) => wb === 'manual',
  bGain: (ae, wb) => wb === 'manual',
  colorTemp: (ae, wb) => wb === 'var',
};

function findLook(id) {
  const l = [...BUILTIN_LOOKS, ...config.data.looks].find((x) => x.id === id);
  if (!l) throw httpError(404, 'Unknown image preset');
  return l;
}

async function captureLook(cam) {
  const st = await cam.conn.refreshState();
  const values = {};
  for (const k of IMAGE_PARAMS) if (st[k] !== undefined && st[k] !== 'unknown' && !cam.conn.unsupported.has(k)) values[k] = st[k];
  return values;
}

async function applyLook(cam, values) {
  if (!cam.conn.connected) throw httpError(409, `${cam.cfg.name} is not connected`);
  const st = cam.conn.state;
  const ae = values.aeMode ?? st.aeMode, wb = values.wbMode ?? st.wbMode, ec = values.expCompOn ?? st.expCompOn;
  const applied = [], skipped = [];
  for (const k of APPLY_ORDER) {
    if (values[k] === undefined) continue;
    if (cam.conn.unsupported.has(k) || (MODES[k] && cam.conn.unsupported.has(`${k}:${values[k]}`)) || (cam.conn.limited && !DATAVIDEO_DOCUMENTED.has(k)) || (RELEVANT[k] && !RELEVANT[k](ae, wb, ec))) { skipped.push(k); continue; }
    const r = await setParam(cam, k, values[k]).catch((e) => ({ ok: false, error: e.message }));
    (r && r.ok === false ? skipped : applied).push(k);
  }
  setTimeout(() => cam.conn.connected && cam.conn.refreshState().catch(() => {}), 600);
  return { camera: cam.cfg.name, applied, skipped };
}

const liveCams = () => config.data.cameras.map((c) => ({ cfg: c, ...cams.get(c.id) })).filter((c) => c.conn && c.conn.connected);

// ---------------------------------------------------------------------------
// vMix tally
// ---------------------------------------------------------------------------
function parseHex(hex) {
  const bytes = String(hex || '').trim().split(/[\s,]+/).filter(Boolean).map((h) => parseInt(h, 16));
  return bytes.length && bytes.every((b) => b >= 0 && b <= 255) ? bytes : null;
}

function sendTallyLamp(camCfg, st) {
  const s = config.data.settings, live = cams.get(camCfg.id);
  if (!live || !live.conn.connected || s.tallyLamp === 'off') return;
  const h = s.tallyHex;
  let hex = h.off;
  if (st === 'program') hex = h.program;
  else if (st === 'preview' && s.tallyLamp === 'program+preview' && h.preview) hex = h.preview;
  const bytes = parseHex(hex);
  if (!bytes) return;
  if (bytes[0] >= 0x81 && bytes[0] <= 0x87) bytes[0] = 0x80 + camCfg.addr; // follow the camera's VISCA address
  live.conn.send(bytes).catch(() => {});
}

function updateTally({ forceLamp = false } = {}) {
  const out = {};
  for (const c of config.data.cameras) {
    const n = vmix.status === 'connected' ? vmix.resolve(c.vmixInput) : null;
    const st = n ? vmix.stateOf(n) : 'off';
    out[c.id] = st;
    if (tallyState.get(c.id) !== st || forceLamp) { tallyState.set(c.id, st); sendTallyLamp(c, st); }
  }
  broadcast('tally', out);
}

vmix.on('tally', () => updateTally());
vmix.on('inputs', () => { broadcast('vmix', vmixPublic()); updateTally(); });
vmix.on('status', () => broadcast('vmix', vmixPublic()));
vmix.configure(config.data.settings.vmix);

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------
function httpError(status, message) { const e = new Error(message); e.status = status; return e; }

function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) res.write(msg);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 1e6) { reject(httpError(413, 'Body too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(httpError(400, 'Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(body));
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

function serveStatic(req, res, pathname) {
  if (pathname === '/install' || pathname === '/install.html') {
    return fs.readFile(path.join(__dirname, 'INSTALL.html'), (err, buf) => {
      if (err) return json(res, 404, { error: 'Not found' });
      res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache' }); res.end(buf);
    });
  }
  const rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) return json(res, 403, { error: 'Forbidden' });
  fs.readFile(file, (err, buf) => {
    if (err) return json(res, 404, { error: 'Not found' });
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}

const newId = () => 'cam-' + Math.random().toString(36).slice(2, 8);

function validateCamera(b, existing = {}) {
  const protocol = String(b.protocol ?? existing.protocol ?? 'dvip');
  if (!PROTOCOLS[protocol]) throw httpError(400, `Protocol must be one of: ${Object.keys(PROTOCOLS).join(', ')}`);
  const c = {
    id: existing.id || newId(),
    name: String(b.name ?? existing.name ?? 'Camera').slice(0, 40),
    ip: String(b.ip ?? existing.ip ?? '').trim(),
    protocol,
    port: Number(b.port || (protocol === existing.protocol && existing.port) || PROTOCOLS[protocol].port),
    stream: String(b.stream ?? existing.stream ?? '').trim().slice(0, 400),
    addr: Number(b.addr ?? existing.addr ?? 1),
    color: String(b.color ?? existing.color ?? '#3b82f6').slice(0, 20),
    vmixInput: existing.vmixInput || null,
    kelvinHttp: existing.kelvinHttp || null,
  };
  if (b.vmixInput !== undefined) {
    const v = b.vmixInput;
    if (!v || v === 'none') c.vmixInput = null;
    else if (typeof v === 'object') c.vmixInput = { key: String(v.key || ''), number: Number(v.number) || null, title: String(v.title || '').slice(0, 60) };
    else if (/^\d+$/.test(String(v))) {
      const inp = vmix.inputs.find((x) => x.number === Number(v));
      c.vmixInput = inp ? { key: inp.key, number: inp.number, title: inp.title } : { key: '', number: Number(v), title: '' };
    }
    else {
      const inp = vmix.inputs.find((x) => x.key === v);
      c.vmixInput = inp ? { key: inp.key, number: inp.number, title: inp.title } : null;
    }
  }
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(c.ip) && !/^[a-zA-Z0-9.-]+$/.test(c.ip)) throw httpError(400, 'Enter a valid IP address');
  if (!(c.port > 0 && c.port < 65536)) throw httpError(400, 'Port must be 1..65535');
  if (!(c.addr >= 1 && c.addr <= 7)) throw httpError(400, 'VISCA address must be 1..7');
  // Common slip: "rtmp://" typed for an RTSP address on port 554.
  if (/^rtmp:\/\/[^/]+:554(\/|$)/i.test(c.stream)) c.stream = 'rtsp' + c.stream.slice(4);
  if (c.stream && !/^[a-z][a-z0-9+.-]*:\/\/\S+$/i.test(c.stream)) throw httpError(400, 'Video stream must be a URL such as rtsp://192.168.1.101:554/live/av1');
  if (b.kelvinRemove === true || b.kelvinRemove === 'on') c.kelvinHttp = null;
  else if (b.kelvinCurl && String(b.kelvinCurl).trim()) c.kelvinHttp = kelvinFromCurl(b.kelvinCurl, b.kelvinValue, existing.kelvinHttp);
  if (c.kelvinHttp) {
    // Username / password typed in the dialog win over any found in the pasted command; empty keeps the old one.
    if (b.kelvinUser !== undefined && String(b.kelvinUser).trim()) c.kelvinHttp = { ...c.kelvinHttp, user: String(b.kelvinUser).trim() };
    if (b.kelvinPass !== undefined && String(b.kelvinPass)) c.kelvinHttp = { ...c.kelvinHttp, pass: String(b.kelvinPass) };
  }
  return c;
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
const routes = [];
const route = (method, pattern, handler) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler });

route('GET', '/api/state', () => snapshot());

route('GET', '/api/events', (req, p, res) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'Access-Control-Allow-Origin': '*' });
  res.write(`event: snapshot\ndata: ${JSON.stringify(snapshot())}\n\n`);
  clients.add(res);
  const ping = setInterval(() => res.write(': ping\n\n'), 15000);
  req.on('close', () => { clearInterval(ping); clients.delete(res); });
  return undefined; // keep open
});

// Cameras CRUD
route('POST', '/api/cameras', async (req) => {
  const c = validateCamera(await readBody(req));
  if (config.data.cameras.length >= 8) throw httpError(400, 'Maximum 8 cameras');
  config.data.cameras.push(c); config.save(); attach(c); syncVideo();
  broadcast('snapshot', snapshot());
  return camPublic(c);
});
route('PUT', '/api/cameras/:id', async (req, p) => {
  const { cfg } = findCam(p.id);
  const updated = validateCamera(await readBody(req), cfg);
  const reconnect = updated.ip !== cfg.ip || updated.port !== cfg.port || updated.addr !== cfg.addr || updated.protocol !== cfg.protocol;
  Object.assign(cfg, updated); config.save();
  if (reconnect) { detach(cfg.id); attach(cfg); }
  syncVideo();
  tallyState.delete(cfg.id);
  updateTally();
  broadcast('snapshot', snapshot());
  return camPublic(cfg);
});
route('DELETE', '/api/cameras/:id', (req, p) => {
  const { cfg } = findCam(p.id);
  detach(cfg.id);
  config.data.cameras = config.data.cameras.filter((x) => x.id !== cfg.id);
  delete config.data.presets[cfg.id];
  config.save(); syncVideo(); broadcast('snapshot', snapshot());
  fs.rm(path.join(THUMBS, cfg.id), { recursive: true, force: true }, () => {});
  return { ok: true };
});
route('POST', '/api/cameras/order', async (req) => {
  const { ids } = await readBody(req);
  if (!Array.isArray(ids)) throw httpError(400, 'ids[] required');
  const byId = new Map(config.data.cameras.map((c) => [c.id, c]));
  config.data.cameras = [...ids.filter((i) => byId.has(i)).map((i) => byId.get(i)), ...config.data.cameras.filter((c) => !ids.includes(c.id))];
  config.save(); broadcast('snapshot', snapshot());
  return { ok: true };
});

// Settings
route('PUT', '/api/settings', async (req) => {
  const b = await readBody(req);
  const s = config.data.settings;
  const num = (k, lo, hi) => { if (b[k] !== undefined) { const v = Number(b[k]); if (v >= lo && v <= hi) s[k] = v; } };
  num('presetCount', 4, 64); num('presetBase', 0, 1);
  num('panSpeed', 0.05, 1); num('tiltSpeed', 0.05, 1); num('zoomSpeed', 0.05, 1); num('focusSpeed', 0.05, 1);
  if (b.invertTilt !== undefined) s.invertTilt = !!b.invertTilt;
  if (b.invertPan !== undefined) s.invertPan = !!b.invertPan;
  if (b.protectProgram !== undefined) s.protectProgram = !!b.protectProgram;
  if (b.extraControls !== undefined && !!b.extraControls !== !!s.extraControls) {
    s.extraControls = !!b.extraControls;
    for (const c of config.data.cameras) {
      const live = cams.get(c.id);
      if (!live) continue;
      live.conn.limited = isLimited(c);
      if (live.conn.connected) live.conn.refreshState({ force: true }).catch(() => {});
    }
    setTimeout(() => broadcast('snapshot', snapshot()), 0);
  }
  if (b.vmix) {
    s.vmix = {
      enabled: !!b.vmix.enabled,
      host: String(b.vmix.host ?? s.vmix.host).trim() || '127.0.0.1',
      port: Number(b.vmix.port) > 0 && Number(b.vmix.port) < 65536 ? Number(b.vmix.port) : 8099,
    };
  }
  if (b.tallyLamp !== undefined) {
    if (!['off', 'program', 'program+preview'].includes(b.tallyLamp)) throw httpError(400, 'tallyLamp must be off, program or program+preview');
    if (b.tallyLamp === 'off' && s.tallyLamp !== 'off') { s.tallyLamp = 'program'; config.data.cameras.forEach((c) => sendTallyLamp(c, 'off')); }
    s.tallyLamp = b.tallyLamp;
  }
  if (b.tallyHex) {
    for (const k of ['program', 'preview', 'off']) {
      if (b.tallyHex[k] === undefined) continue;
      const v = String(b.tallyHex[k]).trim();
      if (v && !parseHex(v)) throw httpError(400, `Tally ${k} command is not valid hex`);
      s.tallyHex[k] = v.toUpperCase();
    }
  }
  config.save(); broadcast('settings', s);
  vmix.configure(s.vmix);
  updateTally({ forceLamp: true });
  return s;
});

// Motion
route('POST', '/api/cam/:id/move', async (req, p) => { const b = await readBody(req); return movePanTilt(findCam(p.id), b.pan, b.tilt); });
route('POST', '/api/cam/:id/zoom', async (req, p) => { const b = await readBody(req); return moveLens(findCam(p.id), 'zoom', b.v); });
route('POST', '/api/cam/:id/focus', async (req, p) => { const b = await readBody(req); return moveLens(findCam(p.id), 'focus', b.v); });
route('POST', '/api/cam/:id/stop', async (req, p) => { await stopAll(findCam(p.id)); return { ok: true }; });
route('GET', '/api/cam/:id/stop', async (req, p) => { await stopAll(findCam(p.id)); return { ok: true }; });

// Named commands (image settings etc.)
route('POST', '/api/cam/:id/cmd', async (req, p) => { const b = await readBody(req); return runNamed(findCam(p.id), b.cmd, b.arg); });
route('GET', '/api/cam/:id/home', async (req, p) => runNamed(findCam(p.id), 'home'));

// Direct image parameters
route('POST', '/api/cam/:id/set', async (req, p) => { const b = await readBody(req); return setParam(findCam(p.id), b.param, b.value); });

// Image presets (looks)
route('POST', '/api/looks', async (req) => {
  const b = await readBody(req);
  const cam = findCam(String(b.camera));
  if (!cam.conn.connected) throw httpError(409, 'Camera not connected');
  const name = String(b.name || '').trim().slice(0, 40);
  if (!name) throw httpError(400, 'Give the image preset a name');
  const look = { id: 'l-' + Math.random().toString(36).slice(2, 8), name, values: await captureLook(cam), from: cam.cfg.name, created: new Date().toISOString() };
  config.data.looks.push(look); config.save();
  broadcast('looks', [...BUILTIN_LOOKS, ...config.data.looks]);
  return look;
});
route('PUT', '/api/looks/:lid', async (req, p) => {
  const look = config.data.looks.find((l) => l.id === p.lid);
  if (!look) throw httpError(404, 'Built-in presets cannot be changed');
  const b = await readBody(req);
  if (b.name) look.name = String(b.name).trim().slice(0, 40);
  if (b.camera) { const cam = findCam(String(b.camera)); look.values = await captureLook(cam); look.from = cam.cfg.name; }
  config.save(); broadcast('looks', [...BUILTIN_LOOKS, ...config.data.looks]);
  return look;
});
route('DELETE', '/api/looks/:lid', (req, p) => {
  const before = config.data.looks.length;
  config.data.looks = config.data.looks.filter((l) => l.id !== p.lid);
  if (config.data.looks.length === before) throw httpError(404, 'Built-in presets cannot be deleted');
  config.save(); broadcast('looks', [...BUILTIN_LOOKS, ...config.data.looks]);
  return { ok: true };
});
route('POST', '/api/cam/:id/look/:lid', (req, p) => applyLook(findCam(p.id), findLook(p.lid).values));
route('GET', '/api/cam/:id/look/:lid', (req, p) => applyLook(findCam(p.id), findLook(p.lid).values));
route('POST', '/api/looks/:lid/apply-all', async (req, p) => {
  const look = findLook(p.lid);
  return Promise.all(liveCams().map((c) => applyLook(c, look.values)));
});
// Copy one camera's whole image setup to every other connected camera (camera matching).
route('POST', '/api/cam/:id/match-all', async (req, p) => {
  const src = findCam(p.id);
  const values = await captureLook(src);
  return Promise.all(liveCams().filter((c) => c.cfg.id !== src.cfg.id).map((c) => applyLook(c, values)));
});

// ---------------------------------------------------------------------------
// Kelvin through the camera's own web page. Some cameras (e.g. Datavideo PTC-40) set colour
// temperature only from their web interface, not over VISCA. The user captures that request in
// the browser ("Copy as cURL"); we keep it as a template and replay it with any Kelvin value.
// ---------------------------------------------------------------------------
const KELVIN_TOKENS = { '{kelvin}': (k) => String(k), '{kelvin100}': (k) => String(Math.round(k / 100)), '{kelvin_index}': (k) => String(Math.round((k - 2500) / 100)) };

function kelvinFromCurl(curlText, capturedValue, previous) {
  let req;
  try { req = parseCurl(curlText); } catch (e) { throw httpError(400, e.message); }
  const k = Number(capturedValue || 5600);
  if (!(k >= 1500 && k <= 15000)) throw httpError(400, 'Enter the Kelvin value you chose while capturing (e.g. 5600)');
  // Find how the camera wrote that value: as Kelvin (5600), in hundreds (56) or as a step index (31 = 5600 K).
  const forms = [['{kelvin}', String(k)], ['{kelvin100}', String(Math.round(k / 100))], ['{kelvin_index}', String(Math.round((k - 2500) / 100))]];
  const texts = [req.url, req.body || ''];
  // A standalone number: not part of a longer number, but may sit next to URL-encoding such as %22 or %3A.
  const tokenRe = (v) => new RegExp(`(?<=^|[^0-9.]|%[0-9A-Fa-f]{2})${v}(?=$|[^0-9.]|%)`, 'g');
  const form = forms.find(([, v]) => texts.some((t) => tokenRe(v).test(t)));
  if (!form) throw httpError(400, `The number ${k} isn't in the pasted request. Check the Kelvin value you entered, or capture the request again right after changing Kelvin and clicking Save.`);
  const [token, v] = form;
  const fill = (t) => (t == null ? t : t.replace(tokenRe(v), token));
  return {
    method: req.method, url: fill(req.url), body: fill(req.body), headers: req.headers,
    user: req.user || (previous && previous.user) || '', pass: req.pass || (previous && previous.pass) || '',
    token, last: k,
  };
}

function kelvinPublic(kh) {
  if (!kh) return null;
  const url = kh.url.replace(/\/\/[^/@]*@/, '//'); // never show credentials embedded in the address
  return { method: kh.method, url, body: kh.body ? kh.body.slice(0, 200) : '', token: kh.token, last: kh.last, user: kh.user || '', hasPass: !!kh.pass };
}

route('POST', '/api/cam/:id/kelvin', async (req, p) => {
  const { cfg } = findCam(p.id);
  const kh = cfg.kelvinHttp;
  if (!kh) throw httpError(409, 'No Kelvin request set up for this camera (✎ → Kelvin through the camera\'s web page)');
  const k = Math.round(Number((await readBody(req)).kelvin) / 100) * 100;
  if (!(k >= 2000 && k <= 10000)) throw httpError(400, 'Kelvin must be 2000..10000');
  const fill = (t) => (t == null ? t : Object.entries(KELVIN_TOKENS).reduce((acc, [tok, f]) => acc.split(tok).join(f(k)), t));
  let res;
  try {
    res = await httpRequest({ method: kh.method, url: fill(kh.url), headers: kh.headers, body: fill(kh.body), user: kh.user, pass: kh.pass });
  } catch (e) { throw httpError(502, `Camera web page: ${e.message}`); }
  broadcast('traffic', { id: cfg.id, dir: res.status < 300 ? 'tx' : 'err', hex: `HTTP ${kh.method} → ${res.status} (Kelvin ${k})` });
  if (res.status === 401 || res.status === 403) throw httpError(502, `The camera refused the login (HTTP ${res.status}). Enter the camera's web username and password under ✎ → Kelvin through the camera's web page.`);
  if (res.status >= 300) throw httpError(502, `The camera answered HTTP ${res.status}. Capture the request again (the camera's login session may have expired).`);
  kh.last = k; config.save();
  broadcast('kelvin', { id: cfg.id, kelvin: k });
  return { ok: true, kelvin: k, status: res.status };
});

// Live video: the browser's WebRTC offer is relayed to the local go2rtc, which answers.
route('GET', '/api/video', () => video.public());
route('POST', '/api/video/restart', () => { video.restart(); return video.public(); });
route('POST', '/api/video/webrtc/:id', async (req, p) => {
  const { cfg } = findCam(p.id);
  if (!cfg.stream) throw httpError(409, 'No video stream URL set for this camera');
  if (video.status !== 'running') throw httpError(503, video.status === 'missing' ? 'The video engine (go2rtc) is not installed' : `Video engine is ${video.status}${video.error ? ': ' + video.error : ''}`);
  const offer = await readBody(req);
  if (offer.type !== 'offer' || typeof offer.sdp !== 'string') throw httpError(400, 'Expected a WebRTC offer');
  const r = await video.request('POST', `/api/webrtc?src=${encodeURIComponent(cfg.id)}`, JSON.stringify(offer)).catch((e) => { throw httpError(502, `Camera video: ${e.message}`); });
  return JSON.parse(r.body.toString());
});

// Preset thumbnails, captured by the browser from the live video when a preset is stored.
route('POST', '/api/cam/:id/preset/:n/thumb', async (req, p) => {
  const { cfg } = findCam(p.id);
  const n = Number(p.n);
  if (!(n >= 1 && n <= 128)) throw httpError(400, 'Preset must be 1..128');
  const { image } = await readBody(req);
  const m = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(String(image || ''));
  if (!m) throw httpError(400, 'Expected a JPEG data URL');
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length > 200000) throw httpError(413, 'Thumbnail too large');
  await fs.promises.mkdir(path.join(THUMBS, cfg.id), { recursive: true });
  await fs.promises.writeFile(path.join(THUMBS, cfg.id, `${n}.jpg`), buf);
  const all = (config.data.presets[cfg.id] ||= {});
  all[n] = { ...(all[n] || {}), thumb: Date.now() };
  config.save(); broadcast('presets', config.data.presets);
  return { ok: true };
});
route('GET', '/api/thumb/:id/:n', (req, p, res) => {
  const { cfg } = findCam(p.id);
  const file = path.join(THUMBS, cfg.id, `${Number(p.n)}.jpg`);
  fs.readFile(file, (err, buf) => {
    if (err) return json(res, 404, { error: 'No thumbnail' });
    res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'max-age=31536000, immutable' });
    res.end(buf);
  });
  return undefined;
});

// vMix
route('GET', '/api/vmix', () => ({ ...vmixPublic(), tally: Object.fromEntries(tallyState) }));

// Presets — GET variants make it trivial to trigger from vMix / Companion / a browser bookmark later.
async function presetAction(id, n, action) {
  const cam = findCam(id);
  const num = Number(n);
  if (!(num >= 1 && num <= 128)) throw httpError(400, 'Preset must be 1..128');
  const visca = num - 1 + config.data.settings.presetBase;
  const build = { recall: cmd.presetRecall, store: cmd.presetStore, clear: cmd.presetClear }[action];
  if (!build) throw httpError(400, 'Action must be recall, store or clear');
  const r = await cam.conn.send(build(cam.cfg.addr, visca));
  broadcast('preset', { id: cam.cfg.id, n: num, action });
  return r;
}
route('POST', '/api/cam/:id/preset/:n/:action', (req, p) => presetAction(p.id, p.n, p.action));
route('GET', '/api/cam/:id/preset/:n/recall', (req, p) => presetAction(p.id, p.n, 'recall'));
route('PUT', '/api/cam/:id/preset/:n', async (req, p) => {
  const { cfg } = findCam(p.id);
  const b = await readBody(req);
  const all = (config.data.presets[cfg.id] ||= {});
  const cur = all[p.n] || {};
  const next = { name: String(b.name ?? cur.name ?? '').slice(0, 24), color: String(b.color ?? cur.color ?? '').slice(0, 20) };
  if (cur.thumb) next.thumb = cur.thumb;
  if (!next.name && !next.color && !next.thumb) delete all[p.n]; else all[p.n] = next;
  config.save(); broadcast('presets', config.data.presets);
  return next;
});

// Camera state / diagnostics
route('POST', '/api/cam/:id/refresh', async (req, p) => findCam(p.id).conn.refreshState({ force: true }));
route('POST', '/api/cam/:id/reconnect', (req, p) => { findCam(p.id).conn.reconnect(); return { ok: true }; });
route('POST', '/api/cam/:id/raw', async (req, p) => {
  const { hex } = await readBody(req);
  const bytes = String(hex || '').trim().split(/[\s,]+/).filter(Boolean).map((h) => parseInt(h, 16));
  if (!bytes.length || bytes.some((b) => !(b >= 0 && b <= 255))) throw httpError(400, 'Enter hex bytes, e.g. 81 01 06 04 FF');
  const res = await findCam(p.id).conn.send(bytes, { inquiry: bytes[1] === 0x09 });
  return Array.isArray(res) ? { ok: true, reply: res.map((b) => b.toString(16).padStart(2, '0').toUpperCase()).join(' ') } : res;
});

// Discovery & network config (UDP)
route('GET', '/api/discover', async () => discover({ timeout: 1500 }));
route('GET', '/api/network/:ip', async (req, p) => {
  const [info, model] = await Promise.all([network.getInfo(p.ip), network.getModelName(p.ip).catch(() => '')]);
  return { ...info, model };
});
route('POST', '/api/network/:ip', async (req, p) => {
  const b = await readBody(req);
  const done = [];
  if (b.hostname !== undefined) { await network.setHostname(p.ip, b.hostname); done.push('hostname'); }
  if (b.dhcp === true) { await network.setDhcp(p.ip, true); done.push('dhcp'); }
  else {
    if (b.dhcp === false) { await network.setDhcp(p.ip, false); done.push('dhcp'); }
    if (b.netmask) { await network.setNetmask(p.ip, b.netmask); done.push('netmask'); }
    if (b.newIp && b.gateway) { await network.setIpAndGateway(p.ip, b.newIp, b.gateway); done.push('ip'); }
  }
  if (b.reboot) { await network.reboot(p.ip); done.push('reboot'); }
  return { ok: true, done };
});

// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }
  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = url.pathname.match(r.re);
    if (!m) continue;
    try {
      const out = await r.handler(req, m.groups || {}, res, url);
      if (out !== undefined && !res.headersSent) json(res, 200, out);
    } catch (e) {
      if (!res.headersSent) json(res, e.status || 500, { error: e.message });
    }
    return;
  }
  json(res, 404, { error: 'Unknown API route' });
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\nPort ${PORT} is already in use. Start with another port, e.g.  PORT=8090 node server.js\n`);
  else console.error(e);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log('\n  PTZ-Commander is running\n');
  console.log(`  On this computer:   http://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) console.log(`  On your network:    http://${i.address}:${PORT}`);
  }
  console.log(`\n  Config file: ${DATA_FILE}`);
  console.log(video.installed ? '  Live video: go2rtc found' : '  Live video: not installed (run get-video-windows.bat to enable camera previews)');
  console.log('  Press Ctrl+C to stop.\n');
  syncVideo();
  if (!video.installed) video.restart();
});

function shutdown() {
  video.stop();
  for (const c of cams.values()) { stopAll(c).catch(() => {}); }
  setTimeout(() => process.exit(0), 200);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
