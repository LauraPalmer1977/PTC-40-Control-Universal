@echo off
setlocal
title PTZ-Commander - keep this window open
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is not installed on this computer.
  echo.
  echo   1. Your browser will now open https://nodejs.org
  echo   2. Download the LTS "Windows Installer (.msi)" and install it with the default options
  echo   3. Double-click start-windows.bat again
  echo.
  start "" https://nodejs.org/en/download
  pause
  exit /b 1
)

node -e "process.exit(Number(process.versions.node.split('.')[0]) < 18 ? 1 : 0)"
if errorlevel 1 (
  echo.
  echo   Your Node.js version is too old. Version 18 or newer is required.
  echo   Install the current LTS version from https://nodejs.org and try again.
  echo.
  pause
  exit /b 1
)

if "%PORT%"=="" set PORT=8080
start "" /b cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:%PORT%"
node server.js
echo.
echo   The controller has stopped. Press any key to close this window.
pause >nul
