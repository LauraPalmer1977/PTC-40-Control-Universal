@echo off
setlocal
title PTC-40 Controller - install live video
cd /d "%~dp0"
:: Downloads go2rtc (free, MIT licence, https://github.com/AlexxIT/go2rtc) into the "bin" folder.
:: go2rtc turns each camera's RTSP stream into low-latency WebRTC for the browser.
set "VER=v1.9.9"
set "ARCH=win64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=win_arm64"
set "URL=https://github.com/AlexxIT/go2rtc/releases/download/%VER%/go2rtc_%ARCH%.zip"

echo.
echo   Downloading go2rtc %VER% (%ARCH%) ...
echo   %URL%
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; New-Item -ItemType Directory -Force -Path 'bin' | Out-Null; $zip=Join-Path $env:TEMP 'go2rtc.zip'; Invoke-WebRequest -UseBasicParsing -Uri $env:URL -OutFile $zip; Expand-Archive -Force -Path $zip -DestinationPath 'bin'; Remove-Item $zip"
if errorlevel 1 goto failed
if not exist "bin\go2rtc.exe" goto failed

echo   Live video is installed: %~dp0bin\go2rtc.exe
echo.
echo   Next:
echo     1. Run allow-firewall-windows.bat so tablets and phones can see the video.
echo     2. Start the controller with start-windows.bat.
echo     3. Click the pencil on each camera tab and paste its RTSP address into "Video stream".
echo.
pause
exit /b 0

:failed
echo.
echo   The download failed. Check the internet connection and try again, or download
echo   go2rtc_%ARCH%.zip by hand from https://github.com/AlexxIT/go2rtc/releases/tag/%VER%
echo   and put go2rtc.exe in the "bin" folder inside the controller folder.
echo.
pause
exit /b 1
