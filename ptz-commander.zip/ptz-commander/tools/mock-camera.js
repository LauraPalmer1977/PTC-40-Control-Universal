'use strict';
// A fake DVIP / VISCA camera for testing the controller without hardware.
//   node tools/mock-camera.js                 -> Datavideo DVIP on TCP 5002 + UDP discovery on 5002
//   node tools/mock-camera.js --port 5003 --no-udp --name "Mock 2"
//   node tools/mock-camera.js --proto visca-tcp --port 5678      (PTZOptics / Avkans style)
//   node tools/mock-camera.js --proto visca-udp --port 1259
//   node tools/mock-camera.js --proto sony-udp  --port 52381
//   add --no-var to reject VAR / Kelvin white balance like a camera that lacks it

const net = require('net');
const dgram = require('dgram');

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const PORT = Number(opt('--port', 5002));
const NAME = opt('--name', 'PTC-40');
const PROTO = opt('--proto', 'dvip');
const NO_VAR = args.includes('--no-var'); // behave like a camera without VAR / Kelvin white balance
const UDP = PROTO === 'dvip' && !args.includes('--no-udp');

const hex = (b) => Array.from(b, (x) => x.toString(16).padStart(2, '0').toUpperCase()).join(' ');
const frame = (bytes) => Buffer.from([0, bytes.length + 2, ...bytes]);
// Camera state keyed by VISCA category byte (81 01 04 <cat> ...). 0x62 (freeze) is left out on
// purpose so the "not supported by this camera" path in the UI can be tested.
const FOUR_NIBBLE = new Set([0x4b, 0x4a, 0x4c, 0x4d, 0x4e, 0x43, 0x44, 0x42, 0x47, 0x49, 0x4f]);
const st = {
  0x00: 2, 0x38: 2, 0x39: 0, 0x35: 0, 0x47: 0, 0x4b: 0x0d, 0x4a: 0x07, 0x4c: 0, 0x4d: 0x0f, 0x4e: 7,
  0x43: 0x80, 0x44: 0x80, 0x42: 5, 0x49: 4, 0x4f: 7, 0x5b: 0, 0x53: 2,
  0x33: 3, 0x3e: 3, 0x3d: 3, 0x66: 3, 0x61: 3, 0x37: 3, 0x63: 0,
  0x20: 0x1f, // colour temperature (VAR): 00h = 2500 K … 37h = 8000 K
};
const presets = {};
const RELATIVE = { 0x0b: [0x4b, 0x11], 0x0a: [0x4a, 0x15], 0x0c: [0x4c, 0x0f], 0x0d: [0x4d, 0x1f], 0x0e: [0x4e, 0x0e], 0x03: [0x43, 0xff], 0x04: [0x44, 0xff], 0x02: [0x42, 0x0f] };
const DEFAULTS = { 0x4b: 0x0d, 0x4a: 0x07, 0x4c: 0, 0x4d: 0x0f, 0x4e: 7, 0x43: 0x80, 0x44: 0x80, 0x42: 5 };

function reply(m) {
  const ACK = [[0x90, 0x41, 0xff], [0x90, 0x51, 0xff]];
  const ERR = [[0x90, 0x60, 0x02, 0xff]];
  if (m[1] === 0x09 && m[2] === 0x04) {
    const cat = m[3];
    if (!(cat in st) || (NO_VAR && cat === 0x20)) return ERR;
    const v = st[cat];
    if (FOUR_NIBBLE.has(cat)) return [[0x90, 0x50, (v >> 12) & 15, (v >> 8) & 15, (v >> 4) & 15, v & 15, 0xff]];
    if (cat === 0x37) return [[0x90, 0x50, v, 0x00, 0xff]];
    if (cat === 0x20) return [[0x90, 0x50, (v >> 4) & 15, v & 15, 0xff]];
    return [[0x90, 0x50, v, 0xff]];
  }
  if (m[1] === 0x01 && m[2] === 0x7e && m[3] === 0x01 && m[4] === 0x0a) {
    console.log(`[tcp] TALLY LAMP ${m[6] === 0x02 ? 'ON (red)' : 'OFF'}`);
    return ACK;
  }
  if (m[1] !== 0x01) return ERR;
  if (m[2] === 0x06) return ACK; // pan/tilt
  if (m[2] !== 0x04) return ERR;
  const cat = m[3];
  if (NO_VAR && (cat === 0x20 || (cat === 0x35 && m[4] === 0x20))) return ERR;
  if (cat === 0x3f) {
    if (m[4] === 0x01) presets[m[5]] = { zoom: st[0x47] };
    if (m[4] === 0x02 && presets[m[5]]) st[0x47] = presets[m[5]].zoom;
    return ACK;
  }
  if (cat === 0x07) { if (m[4]) st[0x47] = Math.max(0, Math.min(0x4000, st[0x47] + ((m[4] & 0xf0) === 0x20 ? 800 : -800))); return ACK; }
  if (cat in RELATIVE) {
    const [c, max] = RELATIVE[cat];
    st[c] = m[4] === 0 ? DEFAULTS[c] : Math.max(0, Math.min(max, st[c] + (m[4] === 2 ? 1 : -1)));
    return ACK;
  }
  if ([0x08, 0x18, 0x10].includes(cat)) return ACK; // focus drive, one-push AF, one-push WB
  if (!(cat in st)) return ERR;
  if (m.length === 9) st[cat] = (m[6] << 4) | m[7];       // 00 00 0p 0q
  else if (cat === 0x20) st[cat] = (m[4] << 4) | m[5];    // 0p 0q
  else if (cat === 0x38 && m[4] === 0x10) st[cat] = st[cat] === 2 ? 3 : 2;
  else st[cat] = m[4];
  return ACK;
}

function* splitVisca(buf) {
  let start = 0;
  for (let i = 0; i < buf.length; i++) if (buf[i] === 0xff) { yield buf.subarray(start, i + 1); start = i + 1; }
}

if (PROTO === 'dvip' || PROTO === 'visca-tcp') {
  net.createServer((sock) => {
    console.log(`[tcp] controller connected from ${sock.remoteAddress}`);
    let rx = Buffer.alloc(0);
    const handle = (m) => {
      if (m[1] !== 0x09) console.log(`[tcp] <- ${hex(m)}`);
      reply(m).forEach((r, i) => setTimeout(() => !sock.destroyed && sock.write(PROTO === 'dvip' ? frame(r) : Buffer.from(r)), 5 + i * 20));
    };
    sock.on('data', (d) => {
      rx = Buffer.concat([rx, d]);
      if (PROTO === 'visca-tcp') {
        const end = rx.lastIndexOf(0xff);
        if (end < 0) return;
        for (const m of splitVisca(rx.subarray(0, end + 1))) handle(m);
        rx = rx.subarray(end + 1);
        return;
      }
      while (rx.length >= 2) {
        const len = rx.readUInt16BE(0);
        if (rx.length < len) break;
        const m = rx.subarray(2, len); rx = rx.subarray(len);
        handle(m);
      }
    });
    sock.on('error', () => {});
    sock.on('close', () => console.log('[tcp] controller disconnected'));
  }).listen(PORT, () => console.log(`Mock camera "${NAME}" (${PROTO}) listening on TCP ${PORT}${UDP ? ' + UDP 5002' : ''}`));
} else {
  const u = dgram.createSocket('udp4');
  u.on('message', (msg, r) => {
    let seq = [0, 0, 0, 0];
    if (PROTO === 'sony-udp') {
      if (msg[0] === 0x02) { u.send(Buffer.from([0x02, 0x01, 0x00, 0x01, ...msg.subarray(4, 8), 0x01]), r.port, r.address); return; }
      seq = [...msg.subarray(4, 8)];
      msg = msg.subarray(8);
    }
    if (msg[1] !== 0x09) console.log(`[udp] <- ${hex(msg)}`);
    reply(msg).forEach((out, i) => setTimeout(() => {
      const pkt = PROTO === 'sony-udp' ? Buffer.from([0x01, 0x11, 0x00, out.length, ...seq, ...out]) : Buffer.from(out);
      u.send(pkt, r.port, r.address);
    }, 5 + i * 20));
  });
  u.bind(PORT, () => console.log(`Mock camera "${NAME}" (${PROTO}) listening on UDP ${PORT}`));
}

if (UDP) {
  const u = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  u.on('message', (msg, r) => {
    const type = msg[2], c = msg[3];
    const head = (resp, body) => { const len = 4 + body.length; return Buffer.from([0, len, type, resp, ...body]); };
    let out = null;
    if (c === 0x00) {
      const host = Buffer.alloc(16); host.write('PTC40-MOCK');
      out = head(0x00, [1, ...host, 0x00, 0x1a, 0x2b, 0x3c, 0x4d, 0x5e, 127, 0, 0, 1, 255, 0, 0, 0, 127, 0, 0, 1, 8, 8, 8, 8, 1, 1, 1, 1, 0]);
    } else if (c === 0x41) {
      const n = Buffer.alloc(16); n.write(NAME); out = head(0x41, [...n]);
    } else out = head(c, [0x06]);
    console.log(`[udp] cmd 0x${c.toString(16)} from ${r.address}`);
    u.send(out, r.port, r.address);
  });
  u.bind(5002);
}
