@echo off
:: Lets tablets/phones reach the controller and lets camera discovery answers through
:: Windows Defender Firewall. Needs administrator rights (Windows will ask).
net session >nul 2>&1
if errorlevel 1 (
  echo Asking Windows for administrator permission...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

set "NODE="
for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
if not defined NODE (
  echo Node.js was not found. Install it first ^(see INSTALL.html^).
  pause
  exit /b 1
)

netsh advfirewall firewall delete rule name="PTZ-Commander" >nul 2>&1
netsh advfirewall firewall delete rule name="PTC-40 Control" >nul 2>&1
netsh advfirewall firewall add rule name="PTZ-Commander" dir=in action=allow program="%NODE%" enable=yes profile=private,domain >nul
netsh advfirewall firewall add rule name="PTZ-Commander" dir=in action=allow protocol=TCP localport=8080 enable=yes profile=private,domain >nul
netsh advfirewall firewall add rule name="PTZ-Commander" dir=in action=allow protocol=TCP localport=8555 enable=yes profile=private,domain >nul
netsh advfirewall firewall add rule name="PTZ-Commander" dir=in action=allow protocol=UDP localport=8555 enable=yes profile=private,domain >nul
if exist "%~dp0bin\go2rtc.exe" netsh advfirewall firewall add rule name="PTZ-Commander" dir=in action=allow program="%~dp0bin\go2rtc.exe" enable=yes profile=private,domain >nul

echo.
echo   Firewall rules added for:
echo     %NODE%
echo     TCP port 8080 ^(web page for tablets and phones^)
echo     TCP/UDP port 8555 ^(live video^)
echo.
echo   They apply to Private and Domain networks. If your network is set to
echo   Public, change it to Private: Settings - Network ^& Internet - Ethernet.
echo.
pause
