@echo off
:: Turns "start the controller when I log in to Windows" on or off.
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PTC-40 Control.lnk"

if exist "%LNK%" (
  choice /m "Autostart is ON. Turn it off"
  if errorlevel 2 exit /b
  del "%LNK%"
  echo Autostart is now OFF.
  pause
  exit /b
)

powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK); $s.TargetPath='%~dp0start-windows.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (
  echo Could not create the startup shortcut.
) else (
  echo Autostart is now ON. The controller will start minimised each time you log in.
  echo Run this file again to turn it off.
)
pause
